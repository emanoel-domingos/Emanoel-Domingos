import { ScrollView, Text, View, TouchableOpacity, FlatList } from "react-native";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useClinicData } from "@/hooks/use-clinic-data";
import { useColors } from "@/hooks/use-colors";
import { Ionicons } from "@expo/vector-icons";
import { useState } from "react";
import { Appointment } from "@/lib/types";

type Step = "service" | "professional" | "date" | "confirm";

export default function NewAppointmentScreen() {
  const router = useRouter();
  const colors = useColors();
  const { services, professionals, addAppointment, getProfessionalById } =
    useClinicData();

  const [step, setStep] = useState<Step>("service");
  const [selectedService, setSelectedService] = useState<string | null>(null);
  const [selectedProfessional, setSelectedProfessional] = useState<string | null>(
    null
  );
  const [selectedDate, setSelectedDate] = useState<string | null>(null);
  const [selectedTime, setSelectedTime] = useState<string | null>(null);

  const currentService = selectedService
    ? services.find((s) => s.id === selectedService)
    : null;
  const currentProfessional = selectedProfessional
    ? getProfessionalById(selectedProfessional)
    : null;

  const handleServiceSelect = (serviceId: string) => {
    setSelectedService(serviceId);
    setStep("professional");
  };

  const handleProfessionalSelect = (professionalId: string) => {
    setSelectedProfessional(professionalId);
    setStep("date");
  };

  const handleDateSelect = (date: string) => {
    setSelectedDate(date);
  };

  const handleTimeSelect = (time: string) => {
    setSelectedTime(time);
    setStep("confirm");
  };

  const handleConfirm = () => {
    if (
      !selectedService ||
      !selectedProfessional ||
      !selectedDate ||
      !selectedTime
    ) {
      return;
    }

    const newAppointment: Appointment = {
      id: `apt-${Date.now()}`,
      serviceId: selectedService,
      professionalId: selectedProfessional,
      date: selectedDate,
      time: selectedTime,
      status: "confirmado",
      createdAt: new Date().toISOString(),
    };

    addAppointment(newAppointment);
    router.push("./");
  };

  const handleBack = () => {
    if (step === "service") {
      router.back();
    } else if (step === "professional") {
      setStep("service");
      setSelectedProfessional(null);
    } else if (step === "date") {
      setStep("professional");
      setSelectedDate(null);
      setSelectedTime(null);
    } else if (step === "confirm") {
      setStep("date");
    }
  };

  const getStepTitle = () => {
    switch (step) {
      case "service":
        return "Selecione o Serviço";
      case "professional":
        return "Escolha o Profissional";
      case "date":
        return "Data e Hora";
      case "confirm":
        return "Confirmar Agendamento";
    }
  };

  const getStepNumber = () => {
    switch (step) {
      case "service":
        return "1";
      case "professional":
        return "2";
      case "date":
        return "3";
      case "confirm":
        return "4";
    }
  };

  return (
    <ScreenContainer className="bg-background">
      <View className="flex-1">
        {/* Header */}
        <View className="flex-row items-center justify-between px-6 pt-6 pb-4">
          <TouchableOpacity
            onPress={handleBack}
            className="w-10 h-10 bg-surface rounded-lg items-center justify-center border border-border active:opacity-80"
          >
            <Ionicons name="chevron-back" size={24} color={colors.foreground} />
          </TouchableOpacity>
          <View className="flex-1 items-center">
            <Text className="text-lg font-bold text-foreground">
              {getStepTitle()}
            </Text>
            <Text className="text-xs text-muted mt-1">
              Passo {getStepNumber()} de 4
            </Text>
          </View>
          <View className="w-10" />
        </View>

        {/* Progress bar */}
        <View className="px-6 pb-4">
          <View className="flex-row gap-2">
            {[1, 2, 3, 4].map((num) => {
              const stepMap: Record<number, Step> = {
                1: "service",
                2: "professional",
                3: "date",
                4: "confirm",
              };
              const isActive =
                ["service", "professional", "date", "confirm"].indexOf(step) >=
                num - 1;

              return (
                <View
                  key={num}
                  className={`flex-1 h-1 rounded-full ${
                    isActive ? "bg-primary" : "bg-border"
                  }`}
                />
              );
            })}
          </View>
        </View>

        {/* Content */}
        <ScrollView
          contentContainerStyle={{ flexGrow: 1 }}
          showsVerticalScrollIndicator={false}
        >
          <View className="flex-1 px-6 pb-20">
            {/* Step 1: Service */}
            {step === "service" && (
              <FlatList
                data={services}
                keyExtractor={(item) => item.id}
                scrollEnabled={false}
                contentContainerStyle={{ gap: 12 }}
                renderItem={({ item: service }) => (
                  <TouchableOpacity
                    onPress={() => handleServiceSelect(service.id)}
                    className={`rounded-xl p-4 border ${
                      selectedService === service.id
                        ? "bg-primary/10 border-primary"
                        : "bg-surface border-border"
                    } active:opacity-80`}
                  >
                    <View className="flex-row justify-between items-start">
                      <View className="flex-1">
                        <Text className="text-sm font-semibold text-foreground">
                          {service.name}
                        </Text>
                        <Text className="text-xs text-muted mt-1">
                          {service.description}
                        </Text>
                      </View>
                      <Text className="text-primary font-bold ml-2">
                        R$ {service.price.toFixed(2)}
                      </Text>
                    </View>
                  </TouchableOpacity>
                )}
              />
            )}

            {/* Step 2: Professional */}
            {step === "professional" && (
              <FlatList
                data={professionals}
                keyExtractor={(item) => item.id}
                scrollEnabled={false}
                contentContainerStyle={{ gap: 12 }}
                renderItem={({ item: professional }) => (
                  <TouchableOpacity
                    onPress={() => handleProfessionalSelect(professional.id)}
                    className={`rounded-xl p-4 border flex-row items-center gap-3 ${
                      selectedProfessional === professional.id
                        ? "bg-primary/10 border-primary"
                        : "bg-surface border-border"
                    } active:opacity-80`}
                  >
                    <View className="w-12 h-12 bg-primary/20 rounded-full items-center justify-center">
                      <Ionicons name="person" size={24} color={colors.primary} />
                    </View>
                    <View className="flex-1">
                      <Text className="text-sm font-semibold text-foreground">
                        {professional.name}
                      </Text>
                      <View className="flex-row items-center gap-1 mt-1">
                        <Ionicons name="star" size={12} color="#FFB800" />
                        <Text className="text-xs font-medium text-foreground">
                          {professional.rating.toFixed(1)}
                        </Text>
                        <Text className="text-xs text-muted">
                          ({professional.reviews})
                        </Text>
                      </View>
                    </View>
                  </TouchableOpacity>
                )}
              />
            )}

            {/* Step 3: Date and Time */}
            {step === "date" && (
              <View className="gap-4">
                {/* Date selection */}
                <View className="gap-2">
                  <Text className="text-sm font-semibold text-foreground">
                    Selecione a Data
                  </Text>
                    <FlatList
                      data={Array.from({ length: 7 }, (_, i) => {
                        const date = new Date();
                        date.setDate(date.getDate() + i);
                        return date.toISOString().split("T")[0];
                      })}
                      keyExtractor={(item) => item}
                      scrollEnabled={false}
                      contentContainerStyle={{ gap: 8 }}
                      numColumns={3}
                      columnWrapperStyle={{ gap: 8 }}
                      renderItem={({ item: date }) => (
                        <TouchableOpacity
                        onPress={() => handleDateSelect(date)}
                        className={`flex-1 rounded-lg p-3 items-center border ${
                          selectedDate === date
                            ? "bg-primary/10 border-primary"
                            : "bg-surface border-border"
                        } active:opacity-80`}
                      >
                        <Text
                          className={`text-xs font-medium ${
                            selectedDate === date
                              ? "text-primary"
                              : "text-muted"
                          }`}
                        >
                          {new Date(date).toLocaleDateString("pt-BR", {
                            weekday: "short",
                          })}
                        </Text>
                        <Text
                          className={`text-sm font-bold ${
                            selectedDate === date
                              ? "text-primary"
                              : "text-foreground"
                          }`}
                        >
                          {new Date(date).getDate()}
                        </Text>
                      </TouchableOpacity>
                    )}
                  />
                </View>

                {/* Time selection */}
                {selectedDate && (
                  <View className="gap-2">
                    <Text className="text-sm font-semibold text-foreground">
                      Selecione a Hora
                    </Text>
                      <FlatList
                        data={
                          currentProfessional?.availableHours || [
                            "09:00",
                            "10:00",
                            "14:00",
                            "15:00",
                            "16:00",
                          ]
                        }
                        keyExtractor={(item) => item}
                        scrollEnabled={false}
                        contentContainerStyle={{ gap: 8 }}
                        numColumns={3}
                        columnWrapperStyle={{ gap: 8 }}
                          renderItem={({ item: time }) => (
                          <TouchableOpacity
                          onPress={() => handleTimeSelect(time)}
                          className={`flex-1 rounded-lg p-3 items-center border ${
                            selectedTime === time
                              ? "bg-primary/10 border-primary"
                              : "bg-surface border-border"
                          } active:opacity-80`}
                        >
                          <Text
                            className={`text-sm font-bold ${
                              selectedTime === time
                                ? "text-primary"
                                : "text-foreground"
                            }`}
                          >
                            {time}
                          </Text>
                        </TouchableOpacity>
                      )}
                    />
                  </View>
                )}
              </View>
            )}

            {/* Step 4: Confirm */}
            {step === "confirm" && (
              <View className="gap-4">
                <View className="bg-surface rounded-xl p-4 border border-border gap-4">
                  <View>
                    <Text className="text-xs text-muted mb-1">Serviço</Text>
                    <Text className="text-base font-semibold text-foreground">
                      {currentService?.name}
                    </Text>
                  </View>

                  <View className="h-px bg-border" />

                  <View>
                    <Text className="text-xs text-muted mb-1">Profissional</Text>
                    <Text className="text-base font-semibold text-foreground">
                      {currentProfessional?.name}
                    </Text>
                  </View>

                  <View className="h-px bg-border" />

                  <View className="flex-row justify-between">
                    <View>
                      <Text className="text-xs text-muted mb-1">Data</Text>
                      <Text className="text-base font-semibold text-foreground">
                        {selectedDate
                          ? new Date(selectedDate).toLocaleDateString("pt-BR")
                          : "-"}
                      </Text>
                    </View>
                    <View>
                      <Text className="text-xs text-muted mb-1">Hora</Text>
                      <Text className="text-base font-semibold text-foreground">
                        {selectedTime || "-"}
                      </Text>
                    </View>
                  </View>

                  <View className="h-px bg-border" />

                  <View>
                    <Text className="text-xs text-muted mb-1">Valor</Text>
                    <Text className="text-lg font-bold text-primary">
                      R$ {currentService?.price.toFixed(2)}
                    </Text>
                  </View>
                </View>

                <TouchableOpacity
                  onPress={handleConfirm}
                  className="bg-primary rounded-xl py-4 items-center active:opacity-80"
                >
                  <Text className="text-white font-bold text-base">
                    Confirmar Agendamento
                  </Text>
                </TouchableOpacity>
              </View>
            )}
          </View>
        </ScrollView>
      </View>
    </ScreenContainer>
  );
}
