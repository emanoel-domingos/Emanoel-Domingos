import { ScrollView, Text, View, TouchableOpacity, FlatList } from "react-native";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useClinicData } from "@/hooks/use-clinic-data";
import { useColors } from "@/hooks/use-colors";
import { Ionicons } from "@expo/vector-icons";
import { useState, useMemo } from "react";
import { WhatsAppFAB } from "@/components/whatsapp-fab";
import { SearchBar } from "@/components/search-bar";
import * as Haptics from "expo-haptics";

export default function ServicesScreen() {
  const router = useRouter();
  const colors = useColors();
  const { services } = useClinicData();
  const [selectedSpecialty, setSelectedSpecialty] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");

  const specialties = Array.from(new Set(services.map((s) => s.specialty)));

  const filteredServices = useMemo(() => {
    let result = selectedSpecialty
      ? services.filter((s) => s.specialty === selectedSpecialty)
      : services;

    if (searchQuery.trim()) {
      result = result.filter(
        (s) =>
          s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          s.description.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    return result;
  }, [selectedSpecialty, searchQuery, services]);

  const handleServicePress = (serviceId: string) => {
    router.push(`./services/${serviceId}`);
  };

  return (
    <ScreenContainer className="bg-background">
      <View className="flex-1">
        {/* Header */}
        <View className="px-6 pt-6 pb-4">
          <Text className="text-2xl font-bold text-foreground">Serviços</Text>
        </View>

        {/* Search bar */}
        <View className="px-6 pb-4">
          <SearchBar
            placeholder="Buscar serviços..."
            value={searchQuery}
            onChangeText={setSearchQuery}
          />
        </View>

        {/* Specialty filter */}
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={{ paddingHorizontal: 24, gap: 8, paddingBottom: 12 }}
        >
          <TouchableOpacity
            onPress={() => setSelectedSpecialty(null)}
            className={`px-4 py-2 rounded-full ${
              selectedSpecialty === null
                ? "bg-primary"
                : "bg-surface border border-border"
            }`}
          >
            <Text
              className={`font-medium ${
                selectedSpecialty === null ? "text-white" : "text-foreground"
              }`}
            >
              Todos
            </Text>
          </TouchableOpacity>
          {specialties.map((specialty) => (
            <TouchableOpacity
              key={specialty}
              onPress={() => setSelectedSpecialty(specialty)}
              className={`px-4 py-2 rounded-full ${
                selectedSpecialty === specialty
                  ? "bg-primary"
                  : "bg-surface border border-border"
              }`}
            >
              <Text
                className={`font-medium ${
                  selectedSpecialty === specialty
                    ? "text-white"
                    : "text-foreground"
                }`}
              >
                {specialty}
              </Text>
            </TouchableOpacity>
          ))}
        </ScrollView>

        {/* Services grid */}
        <FlatList
          data={filteredServices}
          keyExtractor={(item) => item.id}
          numColumns={1}
          contentContainerStyle={{ paddingHorizontal: 24, gap: 12, paddingBottom: 100 }}
          scrollEnabled={false}
          renderItem={({ item: service }) => (
            <TouchableOpacity
              onPress={() => {
                Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                handleServicePress(service.id);
              }}
              className="bg-surface rounded-xl p-4 border border-border active:opacity-80 active:bg-primary/10"
              activeOpacity={0.7}
            >
              <View className="flex-row justify-between items-start mb-3">
                <View className="flex-1">
                  <Text className="text-base font-semibold text-foreground">
                    {service.name}
                  </Text>
                  <View className="flex-row items-center gap-2 mt-1">
                    <View className="bg-primary/20 px-2 py-1 rounded">
                      <Text className="text-xs font-medium text-primary">
                        {service.specialty}
                      </Text>
                    </View>
                  </View>
                </View>
                <Text className="text-primary font-bold text-lg">
                  R$ {service.price.toFixed(2)}
                </Text>
              </View>
              <Text className="text-sm text-muted line-clamp-2 mb-3">
                {service.description}
              </Text>
              <View className="flex-row items-center justify-between">
                <Text className="text-xs text-muted">
                  {service.professionals.length} profissional
                  {service.professionals.length !== 1 ? "is" : ""}
                </Text>
                <Ionicons name="chevron-forward" size={18} color={colors.primary} />
              </View>
            </TouchableOpacity>
          )}
        />
      </View>
      <WhatsAppFAB />
    </ScreenContainer>
  );
}
