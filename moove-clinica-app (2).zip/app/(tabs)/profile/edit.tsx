import { ScrollView, Text, View, TouchableOpacity, TextInput } from "react-native";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useClinicData } from "@/hooks/use-clinic-data";
import { useColors } from "@/hooks/use-colors";
import { Ionicons } from "@expo/vector-icons";
import { useState } from "react";

export default function EditProfileScreen() {
  const router = useRouter();
  const colors = useColors();
  const { userProfile, updateUserProfile } = useClinicData();

  const [name, setName] = useState(userProfile.name);
  const [email, setEmail] = useState(userProfile.email);
  const [phone, setPhone] = useState(userProfile.phone);
  const [birthDate, setBirthDate] = useState(userProfile.birthDate || "");
  const [address, setAddress] = useState(userProfile.address || "");

  const handleSave = () => {
    updateUserProfile({
      name,
      email,
      phone,
      birthDate,
      address,
    });
    router.back();
  };

  const handleCancel = () => {
    router.back();
  };

  return (
    <ScreenContainer className="bg-background">
      <ScrollView
        contentContainerStyle={{ flexGrow: 1 }}
        showsVerticalScrollIndicator={false}
      >
        <View className="flex-1 gap-6 p-6 pb-20">
          {/* Header */}
          <View className="flex-row items-center justify-between">
            <TouchableOpacity
              onPress={handleCancel}
              className="w-10 h-10 bg-surface rounded-lg items-center justify-center border border-border active:opacity-80"
            >
              <Ionicons name="chevron-back" size={24} color={colors.foreground} />
            </TouchableOpacity>
            <Text className="text-2xl font-bold text-foreground flex-1 text-center">
              Editar Perfil
            </Text>
            <View className="w-10" />
          </View>

          {/* Profile picture */}
          <View className="items-center gap-4">
            <View className="w-24 h-24 bg-primary/20 rounded-full items-center justify-center">
              <Ionicons name="person" size={48} color={colors.primary} />
            </View>
            <TouchableOpacity className="bg-primary px-4 py-2 rounded-lg active:opacity-80">
              <Text className="text-white font-semibold text-sm">
                Alterar Foto
              </Text>
            </TouchableOpacity>
          </View>

          {/* Form fields */}
          <View className="gap-4">
            {/* Name */}
            <View className="gap-2">
              <Text className="text-sm font-semibold text-foreground">Nome</Text>
              <TextInput
                value={name}
                onChangeText={setName}
                placeholder="Seu nome completo"
                placeholderTextColor={colors.muted}
                className="bg-surface border border-border rounded-lg px-4 py-3 text-foreground"
                style={{ color: colors.foreground }}
              />
            </View>

            {/* Email */}
            <View className="gap-2">
              <Text className="text-sm font-semibold text-foreground">Email</Text>
              <TextInput
                value={email}
                onChangeText={setEmail}
                placeholder="seu.email@example.com"
                placeholderTextColor={colors.muted}
                keyboardType="email-address"
                className="bg-surface border border-border rounded-lg px-4 py-3 text-foreground"
                style={{ color: colors.foreground }}
              />
            </View>

            {/* Phone */}
            <View className="gap-2">
              <Text className="text-sm font-semibold text-foreground">
                Telefone
              </Text>
              <TextInput
                value={phone}
                onChangeText={setPhone}
                placeholder="(32) 99999-9999"
                placeholderTextColor={colors.muted}
                keyboardType="phone-pad"
                className="bg-surface border border-border rounded-lg px-4 py-3 text-foreground"
                style={{ color: colors.foreground }}
              />
            </View>

            {/* Birth Date */}
            <View className="gap-2">
              <Text className="text-sm font-semibold text-foreground">
                Data de Nascimento
              </Text>
              <TextInput
                value={birthDate}
                onChangeText={setBirthDate}
                placeholder="DD/MM/YYYY"
                placeholderTextColor={colors.muted}
                className="bg-surface border border-border rounded-lg px-4 py-3 text-foreground"
                style={{ color: colors.foreground }}
              />
            </View>

            {/* Address */}
            <View className="gap-2">
              <Text className="text-sm font-semibold text-foreground">
                Endereço
              </Text>
              <TextInput
                value={address}
                onChangeText={setAddress}
                placeholder="Rua, número, complemento"
                placeholderTextColor={colors.muted}
                multiline
                numberOfLines={3}
                className="bg-surface border border-border rounded-lg px-4 py-3 text-foreground"
                style={{ color: colors.foreground, textAlignVertical: "top" }}
              />
            </View>
          </View>

          {/* Buttons */}
          <View className="gap-3 mt-6">
            <TouchableOpacity
              onPress={handleSave}
              className="bg-primary rounded-xl py-4 items-center active:opacity-80"
            >
              <Text className="text-white font-bold text-base">Salvar Alterações</Text>
            </TouchableOpacity>

            <TouchableOpacity
              onPress={handleCancel}
              className="bg-surface border border-border rounded-xl py-4 items-center active:opacity-80"
            >
              <Text className="text-foreground font-bold text-base">Cancelar</Text>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
