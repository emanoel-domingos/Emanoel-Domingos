import { ScrollView, Text, View, TouchableOpacity, Linking } from "react-native";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useClinicData } from "@/hooks/use-clinic-data";
import { useColors } from "@/hooks/use-colors";
import { Ionicons } from "@expo/vector-icons";

export default function ContactScreen() {
  const router = useRouter();
  const colors = useColors();
  const { clinicInfo } = useClinicData();

  const handleCall = () => {
    Linking.openURL(`tel:${clinicInfo.phone.replace(/\D/g, "")}`);
  };

  const handleWhatsApp = () => {
    Linking.openURL(clinicInfo.whatsapp);
  };

  const handleEmail = () => {
    Linking.openURL("mailto:contato@mooveclinica.com.br");
  };

  const handleInstagram = () => {
    Linking.openURL(clinicInfo.instagram);
  };

  const handleWebsite = () => {
    Linking.openURL(clinicInfo.website);
  };

  const handleMaps = () => {
    const address = clinicInfo.address.replace(/\s+/g, "+");
    Linking.openURL(
      `https://www.google.com/maps/search/${address}/@-19.8,-44.5,15z`
    );
  };

  return (
    <ScreenContainer className="bg-background">
      <ScrollView
        contentContainerStyle={{ flexGrow: 1 }}
        showsVerticalScrollIndicator={false}
      >
        <View className="flex-1 gap-6 p-6 pb-20">
          {/* Header */}
          <View className="flex-row items-center justify-between">
            <TouchableOpacity
              onPress={() => router.back()}
              className="w-10 h-10 bg-surface rounded-lg items-center justify-center border border-border active:opacity-80"
            >
              <Ionicons name="chevron-back" size={24} color={colors.foreground} />
            </TouchableOpacity>
            <Text className="text-2xl font-bold text-foreground flex-1 text-center">
              Contato
            </Text>
            <View className="w-10" />
          </View>

          {/* Clinic info card */}
          <View className="bg-gradient-to-br from-primary to-blue-600 rounded-xl p-6 gap-4">
            <Text className="text-white text-lg font-bold">
              {clinicInfo.name}
            </Text>
            <View className="gap-2">
              <Text className="text-white/90 text-sm leading-relaxed">
                {clinicInfo.address}
              </Text>
              <Text className="text-white/80 text-xs">
                Tocantins, Minas Gerais
              </Text>
            </View>
          </View>

          {/* Contact methods */}
          <View className="gap-3">
            <Text className="text-lg font-semibold text-foreground">
              Entre em Contato
            </Text>

            {/* WhatsApp */}
            <TouchableOpacity
              onPress={handleWhatsApp}
              className="bg-surface rounded-xl p-4 border border-border flex-row items-center gap-4 active:opacity-80"
            >
              <View className="w-12 h-12 bg-success/20 rounded-full items-center justify-center">
                <Ionicons name="logo-whatsapp" size={24} color="#22c55e" />
              </View>
              <View className="flex-1">
                <Text className="text-sm font-semibold text-foreground">
                  WhatsApp
                </Text>
                <Text className="text-xs text-muted mt-1">
                  {clinicInfo.phone}
                </Text>
              </View>
              <Ionicons name="chevron-forward" size={20} color={colors.muted} />
            </TouchableOpacity>

            {/* Phone */}
            <TouchableOpacity
              onPress={handleCall}
              className="bg-surface rounded-xl p-4 border border-border flex-row items-center gap-4 active:opacity-80"
            >
              <View className="w-12 h-12 bg-primary/20 rounded-full items-center justify-center">
                <Ionicons name="call" size={24} color={colors.primary} />
              </View>
              <View className="flex-1">
                <Text className="text-sm font-semibold text-foreground">
                  Ligar
                </Text>
                <Text className="text-xs text-muted mt-1">
                  {clinicInfo.phone}
                </Text>
              </View>
              <Ionicons name="chevron-forward" size={20} color={colors.muted} />
            </TouchableOpacity>

            {/* Email */}
            <TouchableOpacity
              onPress={handleEmail}
              className="bg-surface rounded-xl p-4 border border-border flex-row items-center gap-4 active:opacity-80"
            >
              <View className="w-12 h-12 bg-warning/20 rounded-full items-center justify-center">
                <Ionicons name="mail" size={24} color="#f59e0b" />
              </View>
              <View className="flex-1">
                <Text className="text-sm font-semibold text-foreground">
                  Email
                </Text>
                <Text className="text-xs text-muted mt-1">
                  contato@mooveclinica.com.br
                </Text>
              </View>
              <Ionicons name="chevron-forward" size={20} color={colors.muted} />
            </TouchableOpacity>

            {/* Instagram */}
            <TouchableOpacity
              onPress={handleInstagram}
              className="bg-surface rounded-xl p-4 border border-border flex-row items-center gap-4 active:opacity-80"
            >
              <View className="w-12 h-12 bg-pink-500/20 rounded-full items-center justify-center">
                <Ionicons name="logo-instagram" size={24} color="#ec4899" />
              </View>
              <View className="flex-1">
                <Text className="text-sm font-semibold text-foreground">
                  Instagram
                </Text>
                <Text className="text-xs text-muted mt-1">
                  {clinicInfo.instagramHandle}
                </Text>
              </View>
              <Ionicons name="chevron-forward" size={20} color={colors.muted} />
            </TouchableOpacity>

            {/* Website */}
            <TouchableOpacity
              onPress={handleWebsite}
              className="bg-surface rounded-xl p-4 border border-border flex-row items-center gap-4 active:opacity-80"
            >
              <View className="w-12 h-12 bg-blue-500/20 rounded-full items-center justify-center">
                <Ionicons name="globe" size={24} color="#3b82f6" />
              </View>
              <View className="flex-1">
                <Text className="text-sm font-semibold text-foreground">
                  Website
                </Text>
                <Text className="text-xs text-muted mt-1">
                  www.mooveclinica.com.br
                </Text>
              </View>
              <Ionicons name="chevron-forward" size={20} color={colors.muted} />
            </TouchableOpacity>
          </View>

          {/* Hours */}
          <View className="gap-3">
            <Text className="text-lg font-semibold text-foreground">
              Horário de Funcionamento
            </Text>

            <View className="bg-surface rounded-xl p-4 border border-border gap-3">
              <View className="flex-row justify-between">
                <Text className="text-sm text-muted">Segunda a Sexta</Text>
                <Text className="text-sm font-semibold text-foreground">
                  {clinicInfo.hours.weekday}
                </Text>
              </View>
              <View className="flex-row justify-between">
                <Text className="text-sm text-muted">Sábado</Text>
                <Text className="text-sm font-semibold text-foreground">
                  {clinicInfo.hours.saturday}
                </Text>
              </View>
              <View className="flex-row justify-between">
                <Text className="text-sm text-muted">Domingo</Text>
                <Text className="text-sm font-semibold text-foreground">
                  {clinicInfo.hours.sunday}
                </Text>
              </View>
            </View>
          </View>

          {/* Map button */}
          <TouchableOpacity
            onPress={handleMaps}
            className="bg-primary rounded-xl py-4 items-center active:opacity-80"
          >
            <View className="flex-row items-center gap-2">
              <Ionicons name="location" size={20} color="#fff" />
              <Text className="text-white font-bold text-base">
                Abrir no Mapa
              </Text>
            </View>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
