import { ScrollView, Text, View, TouchableOpacity } from "react-native";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useClinicData } from "@/hooks/use-clinic-data";
import { useColors } from "@/hooks/use-colors";
import { Ionicons } from "@expo/vector-icons";
import { WhatsAppFAB } from "@/components/whatsapp-fab";

export default function AppointmentsScreen() {
  const router = useRouter();
  const colors = useColors();
  const { appointments, getProfessionalById, getServiceById } = useClinicData();

  const handleNewAppointment = () => {
    // Navigate to schedule screen
    router.push("./appointments/new");
  };

  const groupedAppointments = appointments.reduce(
    (acc, apt) => {
      const date = new Date(apt.date).toLocaleDateString("pt-BR");
      if (!acc[date]) {
        acc[date] = [];
      }
      acc[date].push(apt);
      return acc;
    },
    {} as Record<string, typeof appointments>
  );

  const sortedDates = Object.keys(groupedAppointments).sort(
    (a, b) => new Date(a).getTime() - new Date(b).getTime()
  );

  return (
    <ScreenContainer className="bg-background">
      <ScrollView
        contentContainerStyle={{ flexGrow: 1 }}
        showsVerticalScrollIndicator={false}
      >
        <View className="flex-1 gap-4 p-6 pb-20">
          {/* Header */}
          <View className="flex-row items-center justify-between">
            <Text className="text-2xl font-bold text-foreground">Agenda</Text>
            <TouchableOpacity
              onPress={handleNewAppointment}
              className="bg-primary rounded-lg p-2 active:opacity-80"
            >
              <Ionicons name="add" size={24} color="#fff" />
            </TouchableOpacity>
          </View>

          {/* Appointments list */}
          {sortedDates.length > 0 ? (
            sortedDates.map((date) => (
              <View key={date} className="gap-2">
                <Text className="text-sm font-semibold text-muted uppercase">
                  {date}
                </Text>
                {groupedAppointments[date].map((apt) => {
                  const professional = getProfessionalById(apt.professionalId);
                  const service = getServiceById(apt.serviceId);

                  return (
                    <TouchableOpacity
                      key={apt.id}
                      className="bg-surface rounded-xl p-4 border border-border active:opacity-80"
                    >
                      <View className="flex-row justify-between items-start mb-2">
                        <View className="flex-1">
                          <Text className="text-sm font-semibold text-foreground">
                            {apt.time} - {service?.name}
                          </Text>
                          <Text className="text-xs text-muted mt-1">
                            com {professional?.name}
                          </Text>
                        </View>
                        <View
                          className={`px-2 py-1 rounded ${
                            apt.status === "confirmado"
                              ? "bg-success/20"
                              : apt.status === "cancelado"
                              ? "bg-error/20"
                              : "bg-warning/20"
                          }`}
                        >
                          <Text
                            className={`text-xs font-medium ${
                              apt.status === "confirmado"
                                ? "text-success"
                                : apt.status === "cancelado"
                                ? "text-error"
                                : "text-warning"
                            }`}
                          >
                            {apt.status}
                          </Text>
                        </View>
                      </View>
                      {apt.notes && (
                        <Text className="text-xs text-muted mt-2">
                          Observações: {apt.notes}
                        </Text>
                      )}
                    </TouchableOpacity>
                  );
                })}
              </View>
            ))
          ) : (
            <View className="flex-1 items-center justify-center gap-4">
              <Ionicons
                name="calendar-outline"
                size={64}
                color={colors.muted}
              />
              <Text className="text-muted text-center text-lg">
                Nenhum agendamento
              </Text>
              <TouchableOpacity
                onPress={handleNewAppointment}
                className="bg-primary px-8 py-3 rounded-lg active:opacity-80"
              >
                <Text className="text-white font-semibold">
                  Agendar Agora
                </Text>
              </TouchableOpacity>
            </View>
          )}
        </View>
      </ScrollView>
      <WhatsAppFAB />
    </ScreenContainer>
  );
}
