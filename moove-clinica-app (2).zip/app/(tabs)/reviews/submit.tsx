import {
  ScrollView,
  Text,
  View,
  TouchableOpacity,
  TextInput,
  Alert,
} from "react-native";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useClinicData } from "@/hooks/use-clinic-data";
import { useColors } from "@/hooks/use-colors";
import { Ionicons } from "@expo/vector-icons";
import { useState } from "react";
import { StarRating } from "@/components/star-rating";
import * as Haptics from "expo-haptics";

export default function SubmitReviewScreen() {
  const router = useRouter();
  const colors = useColors();
  const { services, userProfile, addTestimonial } = useClinicData();

  const [selectedService, setSelectedService] = useState<string | null>(null);
  const [rating, setRating] = useState(5);
  const [patientName, setPatientName] = useState(userProfile.name);
  const [reviewText, setReviewText] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async () => {
    if (!selectedService) {
      Alert.alert("Erro", "Por favor, selecione um serviço");
      return;
    }

    if (reviewText.trim().length < 10) {
      Alert.alert("Erro", "O depoimento deve ter pelo menos 10 caracteres");
      return;
    }

    if (patientName.trim().length === 0) {
      Alert.alert("Erro", "Por favor, informe seu nome");
      return;
    }

    setIsSubmitting(true);

    try {
      // Simular envio para backend
      await new Promise((resolve) => setTimeout(resolve, 1500));

      // Adicionar ao mock data
      const service = services.find((s) => s.id === selectedService);
      if (service) {
        addTestimonial({
          id: `testimonial-${Date.now()}`,
          patientName: patientName.trim(),
          service: service.name,
          text: reviewText.trim(),
          rating,
        });
      }

      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);

      Alert.alert(
        "Sucesso!",
        "Obrigado por sua avaliação! Ela será publicada em breve após revisão.",
        [
          {
            text: "OK",
            onPress: () => router.back(),
          },
        ]
      );
    } catch (error) {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
      Alert.alert("Erro", "Ocorreu um erro ao enviar sua avaliação. Tente novamente.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const selectedServiceData = services.find((s) => s.id === selectedService);

  return (
    <ScreenContainer className="bg-background">
      <ScrollView
        contentContainerStyle={{ flexGrow: 1 }}
        showsVerticalScrollIndicator={false}
      >
        <View className="flex-1 gap-6 p-6 pb-20">
          {/* Header */}
          <View className="gap-2">
            <TouchableOpacity onPress={() => router.back()}>
              <View className="flex-row items-center gap-2">
                <Ionicons name="chevron-back" size={24} color={colors.primary} />
                <Text className="text-base font-semibold text-primary">Voltar</Text>
              </View>
            </TouchableOpacity>
            <Text className="text-2xl font-bold text-foreground mt-4">
              Deixe sua Avaliação
            </Text>
            <Text className="text-sm text-muted">
              Sua opinião é muito importante para nós
            </Text>
          </View>

          {/* Service Selection */}
          <View className="gap-3">
            <Text className="text-base font-semibold text-foreground">
              Qual serviço você deseja avaliar? *
            </Text>
            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={{ gap: 8 }}
            >
              {services.map((service) => (
                <TouchableOpacity
                  key={service.id}
                  onPress={() => {
                    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                    setSelectedService(service.id);
                  }}
                  className={`px-4 py-3 rounded-lg border ${
                    selectedService === service.id
                      ? "bg-primary border-primary"
                      : "bg-surface border-border"
                  }`}
                >
                  <Text
                    className={`font-medium text-sm ${
                      selectedService === service.id
                        ? "text-white"
                        : "text-foreground"
                    }`}
                  >
                    {service.name}
                  </Text>
                </TouchableOpacity>
              ))}
            </ScrollView>
          </View>

          {/* Selected Service Info */}
          {selectedServiceData && (
            <View className="bg-primary/10 rounded-lg p-4 border border-primary/20">
              <View className="flex-row items-start gap-3">
                <Ionicons name="checkmark-circle" size={24} color={colors.primary} />
                <View className="flex-1">
                  <Text className="text-sm font-semibold text-foreground">
                    {selectedServiceData.name}
                  </Text>
                  <Text className="text-xs text-muted mt-1">
                    {selectedServiceData.description}
                  </Text>
                </View>
              </View>
            </View>
          )}

          {/* Star Rating */}
          <View className="gap-3">
            <Text className="text-base font-semibold text-foreground">
              Qual sua avaliação? *
            </Text>
            <View className="flex-row items-center gap-3">
              <StarRating rating={rating} onRatingChange={setRating} size={40} />
              <Text className="text-lg font-bold text-primary">
                {rating}.0 / 5.0
              </Text>
            </View>
          </View>

          {/* Patient Name */}
          <View className="gap-2">
            <Text className="text-base font-semibold text-foreground">
              Seu Nome *
            </Text>
            <TextInput
              placeholder="Digite seu nome"
              placeholderTextColor={colors.muted}
              value={patientName}
              onChangeText={setPatientName}
              className="bg-surface border border-border rounded-lg p-4 text-foreground"
              style={{ color: colors.foreground }}
              editable={!isSubmitting}
            />
          </View>

          {/* Review Text */}
          <View className="gap-2">
            <View className="flex-row items-center justify-between">
              <Text className="text-base font-semibold text-foreground">
                Seu Depoimento *
              </Text>
              <Text className="text-xs text-muted">
                {reviewText.length}/500
              </Text>
            </View>
            <TextInput
              placeholder="Compartilhe sua experiência com este serviço..."
              placeholderTextColor={colors.muted}
              value={reviewText}
              onChangeText={(text) => {
                if (text.length <= 500) {
                  setReviewText(text);
                }
              }}
              multiline
              numberOfLines={6}
              className="bg-surface border border-border rounded-lg p-4 text-foreground"
              style={{ color: colors.foreground, textAlignVertical: "top" }}
              editable={!isSubmitting}
            />
            <Text className="text-xs text-muted">
              Mínimo 10 caracteres, máximo 500
            </Text>
          </View>

          {/* Info Box */}
          <View className="bg-warning/10 rounded-lg p-4 border border-warning/20">
            <View className="flex-row items-start gap-3">
              <Ionicons name="information-circle" size={20} color={colors.warning} />
              <Text className="text-xs text-foreground flex-1 leading-relaxed">
                Sua avaliação será revisada antes de ser publicada. Evite conteúdo ofensivo ou spam.
              </Text>
            </View>
          </View>

          {/* Submit Button */}
          <TouchableOpacity
            onPress={handleSubmit}
            disabled={isSubmitting}
            className={`py-4 rounded-lg items-center justify-center ${
              isSubmitting ? "bg-primary/50" : "bg-primary"
            }`}
          >
            {isSubmitting ? (
              <View className="flex-row items-center gap-2">
                <Ionicons name="hourglass" size={20} color="#fff" />
                <Text className="text-white font-semibold">Enviando...</Text>
              </View>
            ) : (
              <View className="flex-row items-center gap-2">
                <Ionicons name="send" size={20} color="#fff" />
                <Text className="text-white font-semibold">Enviar Avaliação</Text>
              </View>
            )}
          </TouchableOpacity>

          {/* Cancel Button */}
          <TouchableOpacity
            onPress={() => router.back()}
            disabled={isSubmitting}
            className="py-3 rounded-lg items-center justify-center border border-border"
          >
            <Text className="text-foreground font-semibold">Cancelar</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
