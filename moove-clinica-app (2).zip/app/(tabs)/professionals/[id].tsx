import { ScrollView, Text, View, TouchableOpacity } from "react-native";
import { useLocalSearchParams, useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useClinicData } from "@/hooks/use-clinic-data";
import { useColors } from "@/hooks/use-colors";
import { Ionicons } from "@expo/vector-icons";

export default function ProfessionalDetailScreen() {
  const router = useRouter();
  const colors = useColors();
  const { id } = useLocalSearchParams<{ id: string }>();
  const { getProfessionalById, getServicesBySpecialty } = useClinicData();

  const professional = id ? getProfessionalById(id) : null;

  if (!professional) {
    return (
      <ScreenContainer className="bg-background items-center justify-center">
        <Text className="text-foreground">Profissional não encontrado</Text>
      </ScreenContainer>
    );
  }

  const services = getServicesBySpecialty(professional.specialty);

  const handleSchedule = () => {
    router.push("./appointments/new");
  };

  const handleContact = () => {
    router.push("./profile/contact");
  };

  return (
    <ScreenContainer className="bg-background">
      <ScrollView
        contentContainerStyle={{ flexGrow: 1 }}
        showsVerticalScrollIndicator={false}
      >
        <View className="flex-1 gap-6 pb-20">
          {/* Header with back button */}
          <View className="flex-row items-center justify-between px-6 pt-6">
            <TouchableOpacity
              onPress={() => router.back()}
              className="w-10 h-10 bg-surface rounded-lg items-center justify-center border border-border active:opacity-80"
            >
              <Ionicons name="chevron-back" size={24} color={colors.foreground} />
            </TouchableOpacity>
            <Text className="text-lg font-bold text-foreground flex-1 text-center">
              Perfil
            </Text>
            <View className="w-10" />
          </View>

          {/* Professional avatar */}
          <View className="items-center gap-4 px-6">
            <View className="w-32 h-32 bg-gradient-to-br from-primary to-blue-600 rounded-full items-center justify-center">
              <Ionicons name="person" size={64} color="#fff" />
            </View>

            <View className="items-center">
              <Text className="text-2xl font-bold text-foreground">
                {professional.name}
              </Text>
              <Text className="text-sm text-muted mt-1">
                {professional.specialty}
              </Text>
            </View>

            {/* Rating */}
            <View className="flex-row items-center gap-2 bg-surface rounded-full px-4 py-2 border border-border">
              <Ionicons name="star" size={16} color="#FFB800" />
              <Text className="text-sm font-semibold text-foreground">
                {professional.rating.toFixed(1)}
              </Text>
              <Text className="text-sm text-muted">
                ({professional.reviews} avaliações)
              </Text>
            </View>
          </View>

          {/* Bio */}
          {professional.bio && (
            <View className="px-6 gap-2">
              <Text className="text-sm text-muted">Sobre</Text>
              <Text className="text-base text-foreground leading-relaxed">
                {professional.bio}
              </Text>
            </View>
          )}

          {/* Specialties */}
          <View className="px-6 gap-3">
            <Text className="text-sm text-muted">Especialidades</Text>
            <View className="flex-row flex-wrap gap-2">
              {professional.specialties.map((specialty) => (
                <View
                  key={specialty}
                  className="bg-primary/20 px-3 py-1 rounded-full border border-primary/30"
                >
                  <Text className="text-xs font-semibold text-primary">
                    {specialty}
                  </Text>
                </View>
              ))}
            </View>
          </View>

          {/* Available hours */}
          <View className="px-6 gap-3">
            <Text className="text-sm text-muted">Horários Disponíveis</Text>
            <View className="flex-row flex-wrap gap-2">
              {professional.availableHours.map((hour) => (
                <View
                  key={hour}
                  className="bg-surface border border-border px-3 py-2 rounded-lg"
                >
                  <Text className="text-xs font-medium text-foreground">
                    {hour}
                  </Text>
                </View>
              ))}
            </View>
          </View>

          {/* Services offered */}
          <View className="px-6 gap-3">
            <Text className="text-sm text-muted">Serviços Oferecidos</Text>
            {services.map((service) => (
              <TouchableOpacity
                key={service.id}
                onPress={() => router.push(`./services/${service.id}`)}
                className="bg-surface rounded-xl p-4 border border-border flex-row items-center justify-between active:opacity-80"
              >
                <View className="flex-1">
                  <Text className="text-sm font-semibold text-foreground">
                    {service.name}
                  </Text>
                  <Text className="text-xs text-muted mt-1">
                    R$ {service.price.toFixed(2)}
                  </Text>
                </View>
                <Ionicons
                  name="chevron-forward"
                  size={20}
                  color={colors.muted}
                />
              </TouchableOpacity>
            ))}
          </View>

          {/* CTA Buttons */}
          <View className="px-6 gap-3 pb-6">
            <TouchableOpacity
              onPress={handleSchedule}
              className="bg-primary rounded-xl py-4 items-center active:opacity-80"
            >
              <View className="flex-row items-center gap-2">
                <Ionicons name="calendar" size={20} color="#fff" />
                <Text className="text-white font-bold text-base">
                  Agendar com {professional.name.split(" ")[0]}
                </Text>
              </View>
            </TouchableOpacity>

            <TouchableOpacity
              onPress={handleContact}
              className="bg-surface border border-border rounded-xl py-4 items-center active:opacity-80"
            >
              <View className="flex-row items-center gap-2">
                <Ionicons
                  name="logo-whatsapp"
                  size={20}
                  color={colors.primary}
                />
                <Text className="text-primary font-bold text-base">
                  Enviar Mensagem
                </Text>
              </View>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
