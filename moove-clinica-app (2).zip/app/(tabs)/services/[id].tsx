import { ScrollView, Text, View, TouchableOpacity } from "react-native";
import { useLocalSearchParams, useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useClinicData } from "@/hooks/use-clinic-data";
import { useColors } from "@/hooks/use-colors";
import { Ionicons } from "@expo/vector-icons";

export default function ServiceDetailScreen() {
  const router = useRouter();
  const colors = useColors();
  const { id } = useLocalSearchParams<{ id: string }>();
  const { getServiceById, getProfessionalById, plans, clinicInfo } =
    useClinicData();

  const service = id ? getServiceById(id) : null;

  if (!service) {
    return (
      <ScreenContainer className="bg-background items-center justify-center">
        <Text className="text-foreground">Serviço não encontrado</Text>
      </ScreenContainer>
    );
  }

  const professionals = service.professionals
    .map((profId) => getProfessionalById(profId))
    .filter(Boolean);

  const handleSchedule = () => {
    router.push("./appointments/new");
  };

  const handleContact = () => {
    // In a real app, this would open WhatsApp with a pre-filled message
    router.push("./profile/contact");
  };

  return (
    <ScreenContainer className="bg-background">
      <ScrollView
        contentContainerStyle={{ flexGrow: 1 }}
        showsVerticalScrollIndicator={false}
      >
        <View className="flex-1 gap-6 pb-20">
          {/* Header with back button */}
          <View className="flex-row items-center justify-between px-6 pt-6">
            <TouchableOpacity
              onPress={() => router.back()}
              className="w-10 h-10 bg-surface rounded-lg items-center justify-center border border-border active:opacity-80"
            >
              <Ionicons name="chevron-back" size={24} color={colors.foreground} />
            </TouchableOpacity>
            <Text className="text-lg font-bold text-foreground flex-1 text-center">
              {service.name}
            </Text>
            <View className="w-10" />
          </View>

          {/* Service image placeholder */}
          <View className="h-48 bg-gradient-to-br from-primary to-blue-600 mx-6 rounded-xl items-center justify-center">
            <Ionicons name="heart" size={64} color="#fff" />
          </View>

          {/* Service info */}
          <View className="px-6 gap-4">
            <View>
              <Text className="text-2xl font-bold text-foreground mb-2">
                {service.name}
              </Text>
              <View className="flex-row items-center gap-2">
                <View className="bg-primary/20 px-3 py-1 rounded-full">
                  <Text className="text-xs font-semibold text-primary">
                    {service.specialty}
                  </Text>
                </View>
              </View>
            </View>

            <View>
              <Text className="text-sm text-muted mb-2">Descrição</Text>
              <Text className="text-base text-foreground leading-relaxed">
                {service.description}
              </Text>
            </View>

            {/* Price */}
            <View className="bg-primary/10 rounded-xl p-4 border border-primary/20">
              <Text className="text-sm text-muted mb-1">Valor da sessão</Text>
              <Text className="text-3xl font-bold text-primary">
                R$ {service.price.toFixed(2)}
              </Text>
            </View>
          </View>

          {/* Professionals */}
          <View className="px-6 gap-3">
            <Text className="text-lg font-semibold text-foreground">
              Profissionais
            </Text>
            {professionals.map((prof) => (
              <TouchableOpacity
                key={prof?.id}
                onPress={() =>
                  router.push(`./professionals/${prof?.id}`)
                }
                className="bg-surface rounded-xl p-4 border border-border flex-row items-center justify-between active:opacity-80"
              >
                <View className="flex-row items-center gap-3 flex-1">
                  <View className="w-12 h-12 bg-primary/20 rounded-full items-center justify-center">
                    <Ionicons name="person" size={24} color={colors.primary} />
                  </View>
                  <View className="flex-1">
                    <Text className="text-sm font-semibold text-foreground">
                      {prof?.name}
                    </Text>
                    <View className="flex-row items-center gap-1 mt-1">
                      <Ionicons name="star" size={12} color="#FFB800" />
                      <Text className="text-xs font-medium text-foreground">
                        {prof?.rating.toFixed(1)}
                      </Text>
                      <Text className="text-xs text-muted">
                        ({prof?.reviews})
                      </Text>
                    </View>
                  </View>
                </View>
                <Ionicons
                  name="chevron-forward"
                  size={20}
                  color={colors.muted}
                />
              </TouchableOpacity>
            ))}
          </View>

          {/* Plans */}
          <View className="px-6 gap-3">
            <Text className="text-lg font-semibold text-foreground">
              Planos Disponíveis
            </Text>
            {plans.slice(0, 2).map((plan) => (
              <View
                key={plan.id}
                className="bg-surface rounded-xl p-4 border border-border"
              >
                <View className="flex-row justify-between items-start mb-2">
                  <View className="flex-1">
                    <Text className="text-sm font-semibold text-foreground">
                      {plan.name}
                    </Text>
                    <Text className="text-xs text-muted mt-1">
                      {plan.frequency}
                    </Text>
                  </View>
                  <Text className="text-primary font-bold">
                    R$ {plan.price.toFixed(2)}
                  </Text>
                </View>
                {plan.description && (
                  <Text className="text-xs text-muted">{plan.description}</Text>
                )}
              </View>
            ))}
          </View>

          {/* CTA Buttons */}
          <View className="px-6 gap-3 pb-6">
            <TouchableOpacity
              onPress={handleSchedule}
              className="bg-primary rounded-xl py-4 items-center active:opacity-80"
            >
              <View className="flex-row items-center gap-2">
                <Ionicons name="calendar" size={20} color="#fff" />
                <Text className="text-white font-bold text-base">
                  Agendar Agora
                </Text>
              </View>
            </TouchableOpacity>

            <TouchableOpacity
              onPress={handleContact}
              className="bg-surface border border-border rounded-xl py-4 items-center active:opacity-80"
            >
              <View className="flex-row items-center gap-2">
                <Ionicons
                  name="logo-whatsapp"
                  size={20}
                  color={colors.primary}
                />
                <Text className="text-primary font-bold text-base">
                  Enviar Mensagem
                </Text>
              </View>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
