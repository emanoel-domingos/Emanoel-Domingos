import { ScrollView, Text, View, TouchableOpacity } from "react-native";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useClinicData } from "@/hooks/use-clinic-data";
import { useColors } from "@/hooks/use-colors";
import { useThemeContext } from "@/lib/theme-provider";
import { Ionicons } from "@expo/vector-icons";
import { WhatsAppFAB } from "@/components/whatsapp-fab";
import { Switch } from "react-native";

export default function ProfileScreen() {
  const router = useRouter();
  const colors = useColors();
  const { userProfile, appointments, clinicInfo } = useClinicData();
  const { colorScheme, setColorScheme } = useThemeContext();
  const isDarkMode = colorScheme === "dark";

  const handleEditProfile = () => {
    router.push("./profile/edit");
  };

  const handleContact = () => {
    // Open WhatsApp
    router.push("./profile/contact");
  };

  const completedAppointments = appointments.filter(
    (apt) => apt.status === "concluído"
  ).length;

  return (
    <ScreenContainer className="bg-background">
      <ScrollView
        contentContainerStyle={{ flexGrow: 1 }}
        showsVerticalScrollIndicator={false}
      >
        <View className="flex-1 gap-6 p-6 pb-20">
          {/* Profile header */}
          <View className="items-center gap-4">
            <View className="w-24 h-24 bg-primary/20 rounded-full items-center justify-center">
              <Ionicons name="person" size={48} color={colors.primary} />
            </View>
            <View className="items-center">
              <Text className="text-2xl font-bold text-foreground">
                {userProfile.name}
              </Text>
              <Text className="text-sm text-muted mt-1">
                {userProfile.email}
              </Text>
            </View>
            <TouchableOpacity
              onPress={handleEditProfile}
              className="bg-primary px-6 py-2 rounded-lg active:opacity-80"
            >
              <Text className="text-white font-semibold">Editar Perfil</Text>
            </TouchableOpacity>
          </View>

          {/* Stats */}
          <View className="flex-row gap-3">
            <View className="flex-1 bg-surface rounded-xl p-4 border border-border items-center">
              <Text className="text-2xl font-bold text-primary">
                {appointments.length}
              </Text>
              <Text className="text-xs text-muted mt-1">Agendamentos</Text>
            </View>
            <View className="flex-1 bg-surface rounded-xl p-4 border border-border items-center">
              <Text className="text-2xl font-bold text-success">
                {completedAppointments}
              </Text>
              <Text className="text-xs text-muted mt-1">Concluídos</Text>
            </View>
          </View>

          {/* Personal info */}
          <View className="gap-3">
            <Text className="text-lg font-semibold text-foreground">
              Informações Pessoais
            </Text>

            <View className="bg-surface rounded-xl p-4 border border-border gap-3">
              <View>
                <Text className="text-xs text-muted mb-1">Telefone</Text>
                <Text className="text-sm font-medium text-foreground">
                  {userProfile.phone}
                </Text>
              </View>

              {userProfile.birthDate && (
                <View>
                  <Text className="text-xs text-muted mb-1">
                    Data de Nascimento
                  </Text>
                  <Text className="text-sm font-medium text-foreground">
                    {new Date(userProfile.birthDate).toLocaleDateString(
                      "pt-BR"
                    )}
                  </Text>
                </View>
              )}

              {userProfile.address && (
                <View>
                  <Text className="text-xs text-muted mb-1">Endereço</Text>
                  <Text className="text-sm font-medium text-foreground">
                    {userProfile.address}
                  </Text>
                </View>
              )}
            </View>
          </View>

          {/* Clinic info */}
          <View className="gap-3">
            <Text className="text-lg font-semibold text-foreground">
              Contato da Clínica
            </Text>

            <View className="bg-surface rounded-xl p-4 border border-border gap-3">
              <TouchableOpacity className="flex-row items-center gap-3 active:opacity-80">
                <View className="w-10 h-10 bg-primary/20 rounded-lg items-center justify-center">
                  <Ionicons name="call" size={18} color={colors.primary} />
                </View>
                <View className="flex-1">
                  <Text className="text-xs text-muted">Telefone</Text>
                  <Text className="text-sm font-medium text-foreground">
                    {clinicInfo.phone}
                  </Text>
                </View>
              </TouchableOpacity>

              <TouchableOpacity className="flex-row items-center gap-3 active:opacity-80">
                <View className="w-10 h-10 bg-primary/20 rounded-lg items-center justify-center">
                  <Ionicons
                    name="logo-whatsapp"
                    size={18}
                    color={colors.primary}
                  />
                </View>
                <View className="flex-1">
                  <Text className="text-xs text-muted">WhatsApp</Text>
                  <Text className="text-sm font-medium text-foreground">
                    (32) 99988-5842
                  </Text>
                </View>
              </TouchableOpacity>

              <TouchableOpacity className="flex-row items-center gap-3 active:opacity-80">
                <View className="w-10 h-10 bg-primary/20 rounded-lg items-center justify-center">
                  <Ionicons
                    name="location"
                    size={18}
                    color={colors.primary}
                  />
                </View>
                <View className="flex-1">
                  <Text className="text-xs text-muted">Endereço</Text>
                  <Text className="text-sm font-medium text-foreground line-clamp-2">
                    {clinicInfo.address}
                  </Text>
                </View>
              </TouchableOpacity>
            </View>
          </View>

          {/* Settings */}
          <View className="gap-3">
            <Text className="text-lg font-semibold text-foreground">
              Configurações
            </Text>

            <View className="bg-surface rounded-xl p-4 border border-border flex-row items-center justify-between">
              <View className="flex-row items-center gap-3">
                <Ionicons
                  name={isDarkMode ? "moon" : "sunny"}
                  size={20}
                  color={colors.primary}
                />
                <Text className="text-sm font-medium text-foreground">
                  Modo {isDarkMode ? "Escuro" : "Claro"}
                </Text>
              </View>
              <Switch
                value={isDarkMode}
                onValueChange={(value) => setColorScheme(value ? "dark" : "light")}
                trackColor={{ false: colors.border, true: colors.primary }}
                thumbColor={isDarkMode ? colors.primary : colors.surface}
              />
            </View>

            <TouchableOpacity className="bg-surface rounded-xl p-4 border border-border flex-row items-center justify-between active:opacity-80">
              <View className="flex-row items-center gap-3">
                <Ionicons
                  name="notifications"
                  size={20}
                  color={colors.primary}
                />
                <Text className="text-sm font-medium text-foreground">
                  Notificações
                </Text>
              </View>
              <Ionicons
                name="chevron-forward"
                size={20}
                color={colors.muted}
              />
            </TouchableOpacity>

            <TouchableOpacity className="bg-surface rounded-xl p-4 border border-border flex-row items-center justify-between active:opacity-80">
              <View className="flex-row items-center gap-3">
                <Ionicons name="help-circle" size={20} color={colors.primary} />
                <Text className="text-sm font-medium text-foreground">
                  Ajuda & Suporte
                </Text>
              </View>
              <Ionicons
                name="chevron-forward"
                size={20}
                color={colors.muted}
              />
            </TouchableOpacity>

            <TouchableOpacity className="bg-error/10 rounded-xl p-4 border border-error/20 flex-row items-center justify-between active:opacity-80">
              <View className="flex-row items-center gap-3">
                <Ionicons name="log-out" size={20} color="#EF4444" />
                <Text className="text-sm font-medium text-error">Sair</Text>
              </View>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>
      <WhatsAppFAB />
    </ScreenContainer>
  );
}
