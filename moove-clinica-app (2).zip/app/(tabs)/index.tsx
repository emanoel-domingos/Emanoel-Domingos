import { ScrollView, Text, View, TouchableOpacity } from "react-native";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useClinicData } from "@/hooks/use-clinic-data";
import { useColors } from "@/hooks/use-colors";
import { Ionicons } from "@expo/vector-icons";
import { WhatsAppFAB } from "@/components/whatsapp-fab";
import { TestimonialCarousel } from "@/components/testimonial-carousel";
import * as Haptics from "expo-haptics";

export default function HomeScreen() {
  const router = useRouter();
  const colors = useColors();
  const {
    userProfile,
    getUpcomingAppointments,
    services,
    testimonials,
    clinicInfo,
  } = useClinicData();

  const upcomingAppointments = getUpcomingAppointments();

  const handleSchedule = () => {
    router.push("./appointments");
  };

  const handleWhatsApp = () => {
    // In a real app, this would open WhatsApp
    // For now, we'll just navigate to contact screen
    router.push("./profile");
  };

  return (
    <ScreenContainer className="bg-background">
      <ScrollView
        contentContainerStyle={{ flexGrow: 1 }}
        showsVerticalScrollIndicator={false}
      >
        <View className="flex-1 gap-6 p-6 pb-20">
          {/* Header with greeting */}
          <View className="gap-2">
            <Text className="text-sm text-muted">Bem-vindo de volta,</Text>
            <Text className="text-3xl font-bold text-foreground">
              {userProfile.name.split(" ")[0]}
            </Text>
          </View>

          {/* Quick actions */}
          <View className="flex-row gap-3">
            <TouchableOpacity
              onPress={() => {
                Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
                handleSchedule();
              }}
              className="flex-1 bg-primary rounded-xl p-4 active:opacity-80 active:scale-95"
              activeOpacity={0.8}
            >
              <View className="flex-row items-center gap-2">
                <Ionicons name="calendar" size={20} color="#fff" />
                <Text className="text-white font-semibold">Agendar</Text>
              </View>
            </TouchableOpacity>

            <TouchableOpacity
              onPress={() => router.push("./profile")}
              className="flex-1 bg-surface rounded-xl p-4 active:opacity-80 border border-border"
            >
              <View className="flex-row items-center gap-2">
                <Ionicons name="person" size={20} color={colors.foreground} />
                <Text className="text-foreground font-semibold">Meus Dados</Text>
              </View>
            </TouchableOpacity>
          </View>

          {/* Upcoming appointments */}
          <View className="gap-3">
            <View className="flex-row items-center justify-between">
              <Text className="text-lg font-semibold text-foreground">
                Próximos Agendamentos
              </Text>
              {upcomingAppointments.length > 0 && (
                <TouchableOpacity
                  onPress={() => router.push("./appointments")}
                  activeOpacity={0.7}
                >
                  <Text className="text-primary font-medium">Ver tudo</Text>
                </TouchableOpacity>
              )}
            </View>

            {upcomingAppointments.length > 0 ? (
              upcomingAppointments.map((apt) => (
                <View
                  key={apt.id}
                  className="bg-surface rounded-xl p-4 border border-border"
                >
                  <View className="flex-row justify-between items-start mb-2">
                    <Text className="text-sm font-semibold text-foreground">
                      {new Date(apt.date).toLocaleDateString("pt-BR")}
                    </Text>
                    <View className="bg-primary/20 px-2 py-1 rounded">
                      <Text className="text-xs font-medium text-primary">
                        {apt.time}
                      </Text>
                    </View>
                  </View>
                  <Text className="text-xs text-muted">
                    Status: {apt.status}
                  </Text>
                </View>
              ))
            ) : (
              <View className="bg-surface rounded-xl p-6 items-center justify-center border border-border">
                <Ionicons
                  name="calendar-outline"
                  size={40}
                  color={colors.muted}
                  style={{ marginBottom: 8 }}
                />
                <Text className="text-muted text-center">
                  Nenhum agendamento próximo
                </Text>
                <TouchableOpacity
                  onPress={handleSchedule}
                  className="mt-4 bg-primary px-6 py-2 rounded-lg"
                >
                  <Text className="text-white font-semibold">Agendar Agora</Text>
                </TouchableOpacity>
              </View>
            )}
          </View>

          {/* Services highlight */}
          <View className="gap-3">
            <Text className="text-lg font-semibold text-foreground">
              Nossos Serviços
            </Text>
            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={{ gap: 12 }}
            >
              {services.map((service) => (
                <TouchableOpacity
                  key={service.id}
                  onPress={() => {
                    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                    router.push(`./services/${service.id}`);
                  }}
                  className="bg-surface rounded-xl p-4 border border-border w-48 active:opacity-80 active:bg-primary/5"
                  activeOpacity={0.7}
                >
                  <Text className="text-sm font-semibold text-foreground mb-1">
                    {service.name}
                  </Text>
                  <Text className="text-xs text-muted mb-3 line-clamp-2">
                    {service.description}
                  </Text>
                  <Text className="text-primary font-bold">
                    R$ {service.price.toFixed(2)}
                  </Text>
                </TouchableOpacity>
              ))}
            </ScrollView>
          </View>

          {/* Testimonials Carousel */}
          {testimonials.length > 0 && (
            <TestimonialCarousel
              testimonials={testimonials}
              title="Depoimentos em Destaque"
            />
          )}

          {/* Contact CTA */}
          <View className="bg-gradient-to-r from-primary to-blue-600 rounded-xl p-6 gap-3">
            <Text className="text-white font-bold text-lg">Precisa de ajuda?</Text>
            <Text className="text-white/90 text-sm">
              Entre em contato conosco via WhatsApp
            </Text>
            <TouchableOpacity
              onPress={handleWhatsApp}
              className="bg-white/20 rounded-lg py-2 px-4 active:opacity-80"
            >
              <View className="flex-row items-center justify-center gap-2">
                <Ionicons name="logo-whatsapp" size={18} color="#fff" />
                <Text className="text-white font-semibold">Enviar Mensagem</Text>
              </View>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>
      <WhatsAppFAB />
    </ScreenContainer>
  );
}
