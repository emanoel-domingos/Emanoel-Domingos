import { ScrollView, Text, View, TouchableOpacity, FlatList } from "react-native";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useClinicData } from "@/hooks/use-clinic-data";
import { useColors } from "@/hooks/use-colors";
import { Ionicons } from "@expo/vector-icons";
import { useState, useMemo } from "react";
import { SearchBar } from "@/components/search-bar";
import { TestimonialCard } from "@/components/testimonial-card";
import { WhatsAppFAB } from "@/components/whatsapp-fab";
import * as Haptics from "expo-haptics";

export default function ReviewsScreen() {
  const router = useRouter();
  const colors = useColors();
  const { testimonials, services } = useClinicData();
  const [selectedService, setSelectedService] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");

  const serviceNames = Array.from(new Set(testimonials.map((t) => t.service)));

  const filteredTestimonials = useMemo(() => {
    let result = selectedService
      ? testimonials.filter((t) => t.service === selectedService)
      : testimonials;

    if (searchQuery.trim()) {
      result = result.filter(
        (t) =>
          t.patientName.toLowerCase().includes(searchQuery.toLowerCase()) ||
          t.text.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    return result.sort((a, b) => b.rating - a.rating);
  }, [selectedService, searchQuery, testimonials]);

  const averageRating =
    testimonials.length > 0
      ? (testimonials.reduce((sum, t) => sum + t.rating, 0) / testimonials.length).toFixed(1)
      : 0;

  return (
    <ScreenContainer className="bg-background">
      <ScrollView
        contentContainerStyle={{ flexGrow: 1 }}
        showsVerticalScrollIndicator={false}
      >
        <View className="flex-1 gap-4 p-6 pb-20">
          {/* Header */}
          <View className="gap-2">
            <Text className="text-2xl font-bold text-foreground">
              Avaliações & Depoimentos
            </Text>
            <Text className="text-sm text-muted">
              Veja o que nossos pacientes dizem
            </Text>
          </View>

          {/* Rating summary and submit button */}
          <View className="gap-3">
            <View className="bg-primary/10 rounded-xl p-4 border border-primary/20">
              <View className="flex-row items-center gap-3">
                <View className="bg-primary rounded-full w-16 h-16 items-center justify-center">
                  <Text className="text-2xl font-bold text-white">
                    {averageRating}
                  </Text>
                </View>
                <View className="flex-1">
                  <Text className="text-sm font-semibold text-foreground">
                    Avaliação Média
                  </Text>
                  <View className="flex-row gap-1 mt-1">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <Ionicons
                        key={i}
                        name={i < Math.round(parseFloat(averageRating as string)) ? "star" : "star-outline"}
                        size={14}
                        color="#FFB800"
                      />
                    ))}
                  </View>
                  <Text className="text-xs text-muted mt-1">
                    {testimonials.length} avaliações
                  </Text>
                </View>
              </View>
            </View>

            {/* Submit review button */}
            <TouchableOpacity
              onPress={() => {
                Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
                router.push("./reviews/submit");
              }}
              className="bg-primary rounded-xl p-4 flex-row items-center justify-center gap-2"
            >
              <Ionicons name="add-circle" size={20} color="#fff" />
              <Text className="text-white font-semibold">Deixar Avaliação</Text>
            </TouchableOpacity>
          </View>

          {/* Search bar */}
          <SearchBar
            placeholder="Buscar depoimentos..."
            value={searchQuery}
            onChangeText={setSearchQuery}
          />

          {/* Service filter */}
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={{ gap: 8 }}
          >
            <TouchableOpacity
              onPress={() => {
                Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                setSelectedService(null);
              }}
              className={`px-4 py-2 rounded-full ${
                selectedService === null
                  ? "bg-primary"
                  : "bg-surface border border-border"
              }`}
            >
              <Text
                className={`font-medium text-sm ${
                  selectedService === null ? "text-white" : "text-foreground"
                }`}
              >
                Todos
              </Text>
            </TouchableOpacity>

            {serviceNames.map((service) => (
              <TouchableOpacity
                key={service}
                onPress={() => {
                  Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                  setSelectedService(service);
                }}
                className={`px-4 py-2 rounded-full ${
                  selectedService === service
                    ? "bg-primary"
                    : "bg-surface border border-border"
                }`}
              >
                <Text
                  className={`font-medium text-sm ${
                    selectedService === service
                      ? "text-white"
                      : "text-foreground"
                  }`}
                >
                  {service}
                </Text>
              </TouchableOpacity>
            ))}
          </ScrollView>

          {/* Testimonials list */}
          {filteredTestimonials.length > 0 ? (
            <View>
              {filteredTestimonials.map((testimonial) => (
                <TestimonialCard
                  key={testimonial.id}
                  testimonial={testimonial}
                />
              ))}
            </View>
          ) : (
            <View className="bg-surface rounded-xl p-8 items-center justify-center border border-border">
              <Ionicons
                name="chatbubble-outline"
                size={40}
                color={colors.muted}
                style={{ marginBottom: 12 }}
              />
              <Text className="text-muted text-center font-medium">
                Nenhum depoimento encontrado
              </Text>
              <Text className="text-muted text-center text-xs mt-2">
                Tente ajustar seus filtros
              </Text>
            </View>
          )}
        </View>
      </ScrollView>
      <WhatsAppFAB />
    </ScreenContainer>
  );
}
