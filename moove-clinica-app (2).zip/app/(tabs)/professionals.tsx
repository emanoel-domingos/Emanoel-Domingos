import { ScrollView, Text, View, TouchableOpacity, FlatList } from "react-native";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useClinicData } from "@/hooks/use-clinic-data";
import { useColors } from "@/hooks/use-colors";
import { Ionicons } from "@expo/vector-icons";
import { useState, useMemo } from "react";
import { WhatsAppFAB } from "@/components/whatsapp-fab";
import { SearchBar } from "@/components/search-bar";
import * as Haptics from "expo-haptics";

export default function ProfessionalsScreen() {
  const router = useRouter();
  const colors = useColors();
  const { professionals } = useClinicData();
  const [selectedSpecialty, setSelectedSpecialty] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");

  const specialties = Array.from(
    new Set(professionals.flatMap((p) => p.specialties))
  );

  const filteredProfessionals = useMemo(() => {
    let result = selectedSpecialty
      ? professionals.filter((p) => p.specialties.includes(selectedSpecialty as any))
      : professionals;

    if (searchQuery.trim()) {
      result = result.filter(
        (p) =>
          p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          p.bio?.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    return result;
  }, [selectedSpecialty, searchQuery, professionals]);

  const handleProfessionalPress = (professionalId: string) => {
    router.push(`./professionals/${professionalId}`);
  };

  return (
    <ScreenContainer className="bg-background">
      <View className="flex-1">
        {/* Header */}
        <View className="px-6 pt-6 pb-4">
          <Text className="text-2xl font-bold text-foreground">Equipe</Text>
        </View>

        {/* Search bar */}
        <View className="px-6 pb-4">
          <SearchBar
            placeholder="Buscar profissional..."
            value={searchQuery}
            onChangeText={setSearchQuery}
          />
        </View>

        {/* Specialty filter */}
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={{ paddingHorizontal: 24, gap: 8, paddingBottom: 12 }}
        >
          <TouchableOpacity
            onPress={() => setSelectedSpecialty(null)}
            className={`px-4 py-2 rounded-full ${
              selectedSpecialty === null
                ? "bg-primary"
                : "bg-surface border border-border"
            }`}
          >
            <Text
              className={`font-medium ${
                selectedSpecialty === null ? "text-white" : "text-foreground"
              }`}
            >
              Todos
            </Text>
          </TouchableOpacity>
          {specialties.map((specialty) => (
            <TouchableOpacity
              key={specialty}
              onPress={() => setSelectedSpecialty(specialty)}
              className={`px-4 py-2 rounded-full ${
                selectedSpecialty === specialty
                  ? "bg-primary"
                  : "bg-surface border border-border"
              }`}
            >
              <Text
                className={`font-medium ${
                  selectedSpecialty === specialty
                    ? "text-white"
                    : "text-foreground"
                }`}
              >
                {specialty}
              </Text>
            </TouchableOpacity>
          ))}
        </ScrollView>

        {/* Professionals grid */}
        <FlatList
          data={filteredProfessionals}
          keyExtractor={(item) => item.id}
          numColumns={2}
          contentContainerStyle={{ paddingHorizontal: 24, gap: 12, paddingBottom: 100 }}
          columnWrapperStyle={{ gap: 12 }}
          scrollEnabled={false}
          renderItem={({ item: professional }) => (
            <TouchableOpacity
              onPress={() => {
                Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                handleProfessionalPress(professional.id);
              }}
              className="flex-1 bg-surface rounded-xl p-4 border border-border active:opacity-80 active:bg-primary/5"
              activeOpacity={0.7}
            >
              <View className="items-center gap-3">
                <View className="w-16 h-16 bg-primary/20 rounded-full items-center justify-center">
                  <Ionicons name="person" size={32} color={colors.primary} />
                </View>
                <View className="items-center">
                  <Text className="text-sm font-semibold text-foreground text-center">
                    {professional.name.split(" ")[0]}
                  </Text>
                  <Text className="text-xs text-muted text-center">
                    {professional.specialty}
                  </Text>
                </View>
                <View className="flex-row items-center gap-1">
                  <Ionicons name="star" size={14} color="#FFB800" />
                  <Text className="text-xs font-semibold text-foreground">
                    {professional.rating.toFixed(1)}
                  </Text>
                  <Text className="text-xs text-muted">
                    ({professional.reviews})
                  </Text>
                </View>
              </View>
            </TouchableOpacity>
          )}
        />
      </View>
      <WhatsAppFAB />
    </ScreenContainer>
  );
}