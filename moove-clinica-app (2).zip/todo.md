# MOOVE Clínica App - TODO

## Fase 1: Configuração e Branding

- [x] Gerar logo personalizado da clínica MOOVE
- [x] Atualizar app.config.ts com nome e logo
- [x] Configurar paleta de cores (verde/azul) no tailwind.config.js
- [x] Criar assets (icon.png, splash-icon.png, favicon.png, android-icon-foreground.png)

## Fase 2: Estrutura Base

- [x] Configurar navegação com Tab Bar (5 abas principais)
- [x] Criar ScreenContainer wrapper para todas as telas
- [x] Implementar ThemeProvider (claro/escuro)
- [x] Configurar AsyncStorage para dados locais
- [x] Criar tipos TypeScript para domínio (Agendamento, Profissional, Serviço, etc.)

## Fase 4: Melhorias e Polimento

- [x] Botão flutuante WhatsApp em todas as telas
- [x] Melhorar feedback visual (animações, transições, press feedback, haptic feedback)
- [x] Adicionar especialidades de Nutrição (Clínica, Esportiva, Nefrologia, Renal)
- [x] Barra de pesquisa em todas as telas principais
- [x] Seção de avaliações e depoimentos
- [x] Formulário interativo para envio de avaliações
- [x] Carrossel de depoimentos na página inicial
- [x] Melhorar layout do menu (tab bar) com design moderno
- [x] Opção de modo escuro/claro no perfil
- [ ] Notificações push de lembretes
- [ ] Integração com backend real

## Fase 3: Telas Principais

### Home / Dashboard
- [x] Criar tela Home com saudação personalizada
- [x] Exibir próximos 3 agendamentos
- [x] Implementar atalhos rápidos
- [x] Adicionar estatísticas rápidas
- [ ] Implementar pull-to-refresh

### Agenda
- [x] Criar tela de Agenda com calendário
- [x] Implementar lista de agendamentos por data
- [ ] Adicionar filtros (profissional, serviço, status)
- [ ] Criar tela de detalhes do agendamento
- [ ] Implementar opções de cancelar/remarcar

### Novo Agendamento (Fluxo)
- [x] Criar modal/fluxo de novo agendamento
- [x] Passo 1: Seleção de Serviço
- [ ] Passo 2: Seleção de Especialidade
- [x] Passo 3: Seleção de Profissional
- [x] Passo 4: Seleção de Data/Hora
- [x] Passo 5: Confirmação
- [ ] Implementar validações

### Serviços
- [x] Criar tela de Serviços com grid/lista
- [x] Implementar cards de serviço
- [x] Criar tela de detalhes do serviço
- [ ] Adicionar funcionalidade de favoritos
- [x] Implementar busca/filtro de serviços

### Profissionais / Equipe
- [x] Criar tela de Profissionais com grid
- [x] Implementar cards de profissional
- [x] Criar tela de perfil do profissional
- [x] Adicionar filtro por especialidade
- [ ] Implementar busca por nome

### Meus Dados / Perfil
- [x] Criar tela de Perfil do usuário
- [x] Exibir informações pessoais
- [x] Mostrar histórico de agendamentos
- [x] Criar tela de Editar Perfil
- [ ] Implementar upload de foto

### Especialidades
- [ ] Criar tela de Especialidades
- [ ] Listar especialidades com descrição
- [ ] Mostrar profissionais por especialidade
- [ ] Implementar navegação para profissionais

### Contato / Localização
- [x] Criar tela de Contato
- [x] Exibir endereço, telefone, email
- [ ] Integrar mapa (Google Maps)
- [x] Adicionar links para WhatsApp e Instagram
- [x] Implementar horário de funcionamento

### Depoimentos / Avaliações
- [ ] Criar tela de Depoimentos
- [ ] Exibir cards de depoimentos
- [ ] Implementar sistema de avaliação
- [ ] Adicionar filtros por serviço/profissional

### Planos de Assinatura
- [ ] Criar tela de Planos
- [ ] Exibir 4 planos (Essencial, Completo, Premium, Avulso)
- [ ] Implementar comparação de planos
- [ ] Adicionar botão de contratação via WhatsApp

### Notificações
- [ ] Criar tela de Notificações
- [ ] Implementar centro de notificações
- [ ] Adicionar histórico de notificações
- [ ] Implementar marcação como lida

### Configurações
- [ ] Criar tela de Configurações
- [ ] Implementar toggle de notificações
- [ ] Adicionar seletor de tema (claro/escuro)
- [ ] Criar opção de logout

## Fase 4: Funcionalidades Avançadas

### Dados e Persistência
- [ ] Implementar dados mock de profissionais (6 profissionais)
- [ ] Implementar dados mock de serviços (6 serviços)
- [ ] Implementar dados mock de especialidades
- [ ] Implementar dados mock de planos
- [ ] Implementar dados mock de depoimentos (3 depoimentos)
- [ ] Criar sistema de persistência com AsyncStorage

### Integração WhatsApp
- [ ] Implementar botão flutuante WhatsApp
- [ ] Criar mensagens pré-preenchidas para agendamento
- [ ] Adicionar links WhatsApp em contato
- [ ] Implementar share via WhatsApp

### Integração Instagram
- [ ] Adicionar link para Instagram da clínica
- [ ] Implementar share de serviços/profissionais

### Integração Google Maps
- [ ] Implementar mapa na tela de Contato
- [ ] Adicionar marcador da clínica
- [ ] Implementar direções

### Notificações
- [ ] Implementar notificações locais
- [ ] Criar lembretes de agendamento
- [ ] Implementar confirmação de agendamento

### Busca e Filtros
- [ ] Implementar busca global
- [ ] Criar filtros avançados
- [ ] Implementar favoritos

## Fase 5: Testes e Polimento

- [ ] Testar fluxos principais end-to-end
- [ ] Validar responsividade em diferentes tamanhos
- [ ] Testar dark mode / light mode
- [ ] Verificar acessibilidade
- [ ] Otimizar performance
- [ ] Corrigir bugs encontrados

## Fase 6: Entrega

- [ ] Criar checkpoint final
- [ ] Gerar APK para Android
- [ ] Testar em dispositivos reais
- [ ] Preparar documentação
- [ ] Entregar ao cliente

---

## Dados Mock Necessários

### Profissionais (6)
1. Claudiane Médice - Fisioterapeuta
2. Andressa Vasconcelos - Fisioterapeuta
3. Ariane Melo - Psicóloga
4. Maycon Cesar Cabral - Nutricionista
5. Milena Mourão - Farmacêutica / Biomédica / Estética Avançada
6. Jocássia Melão - Esteticista

### Serviços (6)
1. Fisioterapia Especializada - Reabilitação
2. Pilates Clínico - Movimento
3. Estética Avançada - Beleza & Saúde
4. Nutrição Clínica - Nutrição
5. Psicologia - Saúde Mental
6. Biomedicina Estética - Procedimentos

### Especialidades
- Reabilitação
- Movimento
- Beleza & Saúde
- Nutrição
- Saúde Mental
- Procedimentos

### Planos (4)
1. Fisioterapia Individual - R$ 85/sessão
2. Plano Essencial - 1×/semana (4 aulas/mês) - R$ 135/mês
3. Plano Completo - 2×/semana (8 aulas/mês) - R$ 220/mês ★ Mais popular
4. Plano Premium - 3×/semana (12 aulas/mês) - R$ 315/mês

### Depoimentos (3)
1. Paciente Estética - Estética Avançada
2. Júlio - Nutrição Clínica
3. Sandra Ribeiro - Pilates Clínico

### Contato
- WhatsApp: (32) 99988-5842
- Instagram: @moove_clinica
- Endereço: Rua Maestro Antônio Bernardino, 73 – Bela Vista, Tocantins – MG
- Horário: (a definir)
