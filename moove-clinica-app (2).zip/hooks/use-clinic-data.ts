import { useState, useCallback } from "react";
import {
  mockProfessionals,
  mockServices,
  mockPlans,
  mockTestimonials,
  mockUserProfile,
  clinicInfo,
} from "@/lib/mock-data";
import {
  Professional,
  ServiceItem,
  Plan,
  Testimonial,
  UserProfile,
  Appointment,
  Specialty,
} from "@/lib/types";

export function useClinicData() {
  const [professionals] = useState<Professional[]>(mockProfessionals);
  const [services] = useState<ServiceItem[]>(mockServices);
  const [plans] = useState<Plan[]>(mockPlans);
  const [testimonials, setTestimonials] = useState<Testimonial[]>(mockTestimonials);
  const [userProfile, setUserProfile] = useState<UserProfile>(mockUserProfile);
  const [appointments, setAppointments] = useState<Appointment[]>([]);

  const getProfessionalById = useCallback(
    (id: string) => professionals.find((p) => p.id === id),
    [professionals]
  );

  const getServiceById = useCallback(
    (id: string) => services.find((s) => s.id === id),
    [services]
  );

  const getProfessionalsBySpecialty = useCallback(
    (specialty: Specialty) =>
      professionals.filter((p) => p.specialties.includes(specialty)),
    [professionals]
  );

  const getServicesBySpecialty = useCallback(
    (specialty: Specialty) =>
      services.filter((s) => s.specialty === specialty),
    [services]
  );

  const addAppointment = useCallback((appointment: Appointment) => {
    setAppointments((prev) => [...prev, appointment]);
  }, []);

  const cancelAppointment = useCallback((appointmentId: string) => {
    setAppointments((prev) =>
      prev.map((apt) =>
        apt.id === appointmentId ? { ...apt, status: "cancelado" } : apt
      )
    );
  }, []);

  const updateUserProfile = useCallback((profile: Partial<UserProfile>) => {
    setUserProfile((prev) => ({ ...prev, ...profile }));
  }, []);

  const getUpcomingAppointments = useCallback(() => {
    const now = new Date();
    return appointments
      .filter((apt) => {
        const aptDate = new Date(apt.date);
        return aptDate > now && apt.status !== "cancelado";
      })
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
      .slice(0, 3);
  }, [appointments]);

  const addTestimonial = useCallback((testimonial: Testimonial) => {
    setTestimonials((prev) => [...prev, testimonial]);
  }, []);

  return {
    professionals,
    services,
    plans,
    testimonials,
    userProfile,
    appointments,
    clinicInfo,
    getProfessionalById,
    getServiceById,
    getProfessionalsBySpecialty,
    getServicesBySpecialty,
    addAppointment,
    cancelAppointment,
    updateUserProfile,
    getUpcomingAppointments,
    addTestimonial,
  };
}
