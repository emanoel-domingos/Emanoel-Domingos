# Design da Interface - MOOVE Clínica App

## Visão Geral

O aplicativo móvel da MOOVE Clínica é uma solução completa para gerenciamento de clientes, agendamentos e serviços. O design segue as diretrizes do iOS Human Interface Guidelines (HIG) com foco em usabilidade com uma mão e orientação portrait (9:16).

**Paleta de Cores:**
- Verde Escuro (#0a4a2e) - Navbar, elementos principais
- Verde Médio (#1a7a4a) - Botões, destaques
- Verde Vivo (#22c55e) - Bordas, tags
- Azul Escuro (#0c2340) - Gradientes
- Off-white (#f8fafc) - Fundos claros
- Texto Escuro (#0f172a) - Textos principais

**Tipografia:**
- Títulos: Cormorant Garamond (300, 400, 600)
- Corpo/UI: Outfit (300, 400, 500, 600, 700)

---

## Lista de Telas

### 1. **Home / Dashboard**
**Conteúdo Principal:**
- Saudação personalizada com nome do usuário
- Próximos agendamentos (cards com data, hora, profissional, serviço)
- Atalhos rápidos (Agendar, Meus Dados, Contato)
- Estatísticas rápidas (Total de atendimentos, Próxima consulta)
- Botão flutuante WhatsApp para contato

**Funcionalidades:**
- Exibir até 3 próximos agendamentos
- Pull-to-refresh para atualizar dados
- Navegação para outras abas

---

### 2. **Agenda / Agendamentos**
**Conteúdo Principal:**
- Calendário interativo (mês/semana)
- Lista de agendamentos por data
- Filtros: Por profissional, Por serviço, Por status (confirmado, pendente, cancelado)
- Cards de agendamento com: data, hora, profissional, serviço, status
- Botão "Novo Agendamento"

**Funcionalidades:**
- Visualizar disponibilidade de profissionais
- Agendar novo atendimento
- Cancelar/Remarcar agendamento
- Receber notificações de confirmação
- Visualizar histórico de agendamentos

---

### 3. **Novo Agendamento (Modal/Fluxo)**
**Conteúdo Principal:**
- Passo 1: Selecionar Serviço (Fisioterapia, Pilates, Estética, Nutrição, Psicologia, Biomedicina)
- Passo 2: Selecionar Especialidade (se aplicável)
- Passo 3: Selecionar Profissional
- Passo 4: Selecionar Data e Hora (com disponibilidade em tempo real)
- Passo 5: Confirmar e Agendar

**Funcionalidades:**
- Validação de campos obrigatórios
- Exibir apenas profissionais disponíveis
- Mostrar preço do serviço
- Opção de salvar como preferência

---

### 4. **Serviços**
**Conteúdo Principal:**
- Grid/Lista de 6 serviços principais
- Cards com: foto, nome, descrição, preço, tag (especialidade)
- Detalhes do serviço ao tocar

**Funcionalidades:**
- Visualizar descrição completa do serviço
- Ver profissionais que oferecem o serviço
- Agendar direto do card
- Compartilhar serviço

---

### 5. **Detalhes do Serviço**
**Conteúdo Principal:**
- Foto do serviço
- Nome e descrição completa
- Preço e planos disponíveis
- Profissionais que oferecem
- Avaliações e depoimentos
- Botão "Agendar Agora"

**Funcionalidades:**
- Adicionar aos favoritos
- Compartilhar via WhatsApp
- Ver disponibilidade de profissionais

---

### 6. **Profissionais / Equipe**
**Conteúdo Principal:**
- Grid de cards com foto, nome, especialidade
- Filtro por especialidade
- Busca por nome

**Funcionalidades:**
- Visualizar perfil completo do profissional
- Ver agenda do profissional
- Agendar com profissional específico
- Avaliar profissional

---

### 7. **Perfil do Profissional**
**Conteúdo Principal:**
- Foto em alta resolução
- Nome, especialidade, formações
- Descrição/Bio
- Horários de atendimento
- Avaliações e comentários
- Botão "Agendar com este Profissional"

**Funcionalidades:**
- Ver disponibilidade
- Agendar direto
- Deixar avaliação
- Compartilhar perfil

---

### 8. **Meus Dados / Perfil**
**Conteúdo Principal:**
- Foto do perfil (com opção de alterar)
- Nome completo
- Email
- Telefone / WhatsApp
- Data de nascimento
- Endereço
- Histórico de atendimentos
- Botão "Editar Perfil"

**Funcionalidades:**
- Editar informações pessoais
- Alterar foto de perfil
- Gerenciar preferências de notificação
- Ver histórico completo de agendamentos
- Baixar recibos/comprovantes

---

### 9. **Editar Perfil**
**Conteúdo Principal:**
- Formulário com campos editáveis
- Foto do perfil com opção de câmera/galeria
- Validação de email e telefone
- Botões "Salvar" e "Cancelar"

**Funcionalidades:**
- Upload de foto
- Validação de dados
- Confirmação de alterações
- Sincronização com backend

---

### 10. **Especialidades**
**Conteúdo Principal:**
- Lista de especialidades (Reabilitação, Movimento, Beleza & Saúde, etc.)
- Descrição de cada especialidade
- Profissionais por especialidade
- Serviços relacionados

**Funcionalidades:**
- Filtrar profissionais por especialidade
- Ver serviços da especialidade
- Agendar com especialista

---

### 11. **Horários / Disponibilidade**
**Conteúdo Principal:**
- Calendário com disponibilidade de profissionais
- Horários disponíveis por profissional
- Filtro por dia da semana
- Indicador de ocupação

**Funcionalidades:**
- Visualizar em tempo real
- Reservar horário
- Receber notificação de cancelamento

---

### 12. **Contato / Localização**
**Conteúdo Principal:**
- Endereço completo
- Telefone / WhatsApp
- Email
- Horário de funcionamento
- Mapa com localização
- Links para redes sociais (Instagram, WhatsApp)

**Funcionalidades:**
- Abrir mapa
- Ligar direto
- Enviar mensagem WhatsApp
- Compartilhar localização
- Seguir no Instagram

---

### 13. **Depoimentos / Avaliações**
**Conteúdo Principal:**
- Cards de depoimentos com foto, nome, serviço
- Estrelas de avaliação
- Texto do depoimento
- Filtro por serviço/profissional

**Funcionalidades:**
- Deixar avaliação
- Filtrar por nota
- Compartilhar depoimento

---

### 14. **Planos de Assinatura**
**Conteúdo Principal:**
- 4 planos disponíveis (Essencial, Completo, Premium, Avulso)
- Frequência, quantidade de aulas/mês, preço
- Benefícios de cada plano
- Botão "Contratar"

**Funcionalidades:**
- Comparar planos
- Contratar plano via WhatsApp
- Visualizar plano ativo do usuário

---

### 15. **Notificações**
**Conteúdo Principal:**
- Centro de notificações
- Confirmação de agendamento
- Lembretes de consulta
- Promoções e novidades
- Histórico de notificações

**Funcionalidades:**
- Marcar como lida
- Deletar notificação
- Configurar preferências

---

### 16. **Configurações**
**Conteúdo Principal:**
- Preferências de notificação
- Tema (claro/escuro)
- Idioma
- Privacidade e segurança
- Sobre o app
- Logout

**Funcionalidades:**
- Toggle de notificações
- Alterar tema
- Gerenciar permissões
- Sair da conta

---

## Fluxos de Usuário Principais

### **Fluxo 1: Novo Agendamento**
1. Usuário toca em "Agendar" na Home
2. Seleciona Serviço → Especialidade → Profissional
3. Escolhe Data e Hora
4. Confirma agendamento
5. Recebe confirmação e notificação

### **Fluxo 2: Visualizar Agenda**
1. Usuário acessa aba "Agenda"
2. Visualiza calendário com agendamentos
3. Toca em um agendamento para ver detalhes
4. Opção de cancelar ou remarcar

### **Fluxo 3: Explorar Serviços**
1. Usuário acessa aba "Serviços"
2. Visualiza grid de serviços
3. Toca em um serviço para ver detalhes
4. Vê profissionais e avaliações
5. Agenda direto ou salva como favorito

### **Fluxo 4: Conhecer Equipe**
1. Usuário acessa aba "Profissionais"
2. Visualiza grid de profissionais
3. Toca em um profissional para ver perfil
4. Vê especialidades e avaliações
5. Agenda com o profissional

### **Fluxo 5: Editar Perfil**
1. Usuário acessa "Meus Dados"
2. Toca em "Editar Perfil"
3. Altera informações
4. Salva alterações
5. Retorna ao perfil

---

## Padrões de Interação

### **Navegação Principal**
- Tab Bar com 5 abas: Home, Agenda, Serviços, Profissionais, Meus Dados
- Cada aba tem seu próprio stack de navegação
- Botão flutuante WhatsApp em todas as telas

### **Cards e Listas**
- Hover/Press: Escala 0.97 + sombra aumentada
- Swipe para ações secundárias (cancelar, remarcar)
- Pull-to-refresh em listas principais

### **Formulários**
- Validação em tempo real
- Feedback visual de erro/sucesso
- Botões desabilitados até preenchimento correto

### **Modais**
- Slide up animation
- Botão de fechar no topo
- Confirmação antes de ações destrutivas

---

## Responsividade

- **Portrait (9:16)**: Layout principal, otimizado para uma mão
- **Breakpoint 900px**: Ajustes para tablets (se necessário)
- **SafeArea**: Respeita notch, home indicator e tab bar

---

## Animações (Sutis)

- Fade-in ao carregar telas
- Scale 0.97 em press de botões
- Slide up em modais
- Pulse no botão WhatsApp flutuante
- Transição suave entre abas

---

## Acessibilidade

- Contraste de cores WCAG AA
- Textos descritivos para ícones
- Tamanho mínimo de toque: 44x44pt
- Suporte a VoiceOver (iOS) e TalkBack (Android)
