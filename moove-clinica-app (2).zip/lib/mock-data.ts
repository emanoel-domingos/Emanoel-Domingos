import { Professional, ServiceItem, Plan, Testimonial, UserProfile } from "./types";

export const mockProfessionals: Professional[] = [
  {
    id: "prof-1",
    name: "Claudiane Médice",
    specialty: "Reabilitação",
    specialties: ["Reabilitação"],
    bio: "Fisioterapeuta especializada em reabilitação e recuperação funcional.",
    rating: 4.8,
    reviews: 24,
    availableHours: ["09:00", "10:00", "14:00", "15:00", "16:00"],
  },
  {
    id: "prof-2",
    name: "Andressa Vasconcelos",
    specialty: "Movimento",
    specialties: ["Movimento"],
    bio: "Fisioterapeuta especializada em pilates clínico e movimento funcional.",
    rating: 4.9,
    reviews: 31,
    availableHours: ["08:00", "09:00", "14:00", "15:00"],
  },
  {
    id: "prof-3",
    name: "Ariane Melo",
    specialty: "Saúde Mental",
    specialties: ["Saúde Mental"],
    bio: "Psicóloga clínica com foco em bem-estar e saúde mental.",
    rating: 4.7,
    reviews: 18,
    availableHours: ["10:00", "11:00", "15:00", "16:00", "17:00"],
  },
  {
    id: "prof-4",
    name: "Maycon Cesar Cabral",
    specialty: "Nutrição",
    specialties: ["Nutrição", "Nutrição Esportiva", "Nefrologia Renal"],
    bio: "Nutricionista clínico com pós-graduação em clínica esportiva e nefrologia renal. Especialista em nutrição clínica, esportiva e doenças renais.",
    rating: 4.8,
    reviews: 22,
    availableHours: ["09:00", "10:00", "11:00", "14:00", "15:00"],
    certifications: [
      "Pós-graduação em Clínica Esportiva",
      "Pós-graduação em Nefrologia Renal",
      "Especialista em Nutrição Clínica",
      "Certified Sports Nutritionist"
    ]
  },
  {
    id: "prof-5",
    name: "Milena Mourão",
    specialty: "Beleza & Saúde",
    specialties: ["Beleza & Saúde", "Procedimentos"],
    bio: "Farmacêutica, Biomédica e especialista em Estética Avançada.",
    rating: 4.9,
    reviews: 28,
    availableHours: ["10:00", "11:00", "14:00", "15:00", "16:00", "17:00"],
  },
  {
    id: "prof-6",
    name: "Jocássia Melão",
    specialty: "Beleza & Saúde",
    specialties: ["Beleza & Saúde"],
    bio: "Esteticista com experiência em procedimentos estéticos avançados.",
    rating: 4.6,
    reviews: 19,
    availableHours: ["09:00", "10:00", "14:00", "15:00", "16:00"],
  },
];

export const mockServices: ServiceItem[] = [
  {
    id: "srv-1",
    name: "Fisioterapia Especializada",
    specialty: "Reabilitação",
    description:
      "Tratamento especializado para reabilitação e recuperação funcional. Ideal para pós-operatório, lesões e disfunções musculoesqueléticas.",
    price: 85,
    professionals: ["prof-1"],
  },
  {
    id: "srv-2",
    name: "Pilates Clínico",
    specialty: "Movimento",
    description:
      "Pilates terapêutico com foco em fortalecimento, flexibilidade e controle postural. Beneficia todo tipo de paciente.",
    price: 85,
    professionals: ["prof-2"],
  },
  {
    id: "srv-3",
    name: "Estética Avançada",
    specialty: "Beleza & Saúde",
    description:
      "Procedimentos estéticos de última geração com tecnologia avançada. Rejuvenescimento, limpeza profunda e tratamentos especializados.",
    price: 150,
    professionals: ["prof-5", "prof-6"],
    relatedServices: ["srv-5", "srv-6"],
  },
  {
    id: "srv-4",
    name: "Nutrição Clínica",
    specialty: "Nutrição",
    description:
      "Consulta nutricional personalizada com plano alimentar específico para seus objetivos. Acompanhamento profissional com especialista em clínica geral.",
    price: 120,
    professionals: ["prof-4"],
    relatedServices: ["srv-7", "srv-8"],
  },
  {
    id: "srv-7",
    name: "Nutrição Esportiva",
    specialty: "Nutrição Esportiva",
    description:
      "Planejamento nutricional especializado para atletas e praticantes de atividade física. Otimização de desempenho, recuperação e composição corporal.",
    price: 140,
    professionals: ["prof-4"],
    relatedServices: ["srv-4", "srv-8", "srv-2"],
  },
  {
    id: "srv-8",
    name: "Nefrologia Renal",
    specialty: "Nefrologia Renal",
    description:
      "Acompanhamento nutricional especializado para pacientes com doenças renais. Controle de sódio, potássio e fósforo com suporte profissional.",
    price: 150,
    professionals: ["prof-4"],
    relatedServices: ["srv-4", "srv-7"],
  },
  {
    id: "srv-5",
    name: "Psicologia",
    specialty: "Saúde Mental",
    description:
      "Atendimento psicológico clínico para bem-estar emocional, ansiedade, estresse e desenvolvimento pessoal. Complementa perfeitamente tratamentos estéticos e de bem-estar.",
    price: 100,
    professionals: ["prof-3"],
    relatedServices: ["srv-3", "srv-6"],
  },
  {
    id: "srv-6",
    name: "Biomedicina Estética",
    specialty: "Procedimentos",
    description:
      "Procedimentos biomédicos estéticos com tecnologia de ponta. Tratamentos seguros e eficazes com acompanhamento nutricional e psicológico.",
    price: 180,
    professionals: ["prof-5"],
    relatedServices: ["srv-3", "srv-4", "srv-5", "srv-7"],
  },
];

export const mockPlans: Plan[] = [
  {
    id: "plan-1",
    name: "Fisioterapia Individual",
    frequency: "Sessão avulsa",
    sessionsPerMonth: 1,
    price: 85,
    description: "Ideal para quem quer começar ou fazer sessões pontuais.",
  },
  {
    id: "plan-2",
    name: "Plano Essencial",
    frequency: "1× por semana",
    sessionsPerMonth: 4,
    price: 135,
    description: "Perfeito para manutenção e prevenção.",
  },
  {
    id: "plan-3",
    name: "Plano Completo",
    frequency: "2× por semana",
    sessionsPerMonth: 8,
    price: 220,
    highlighted: true,
    description: "★ Mais popular - Melhor custo-benefício para resultados visíveis.",
  },
  {
    id: "plan-4",
    name: "Plano Premium",
    frequency: "3× por semana",
    sessionsPerMonth: 12,
    price: 315,
    description: "Máxima intensidade para resultados rápidos e transformadores.",
  },
];

export const mockTestimonials: Testimonial[] = [
  {
    id: "test-1",
    patientName: "Paciente Estética",
    service: "Estética Avançada",
    text: "Adorei os resultados! A equipe é muito profissional e atenciosa. Recomendo muito!",
    rating: 5,
  },
  {
    id: "test-2",
    patientName: "Júlio",
    service: "Nutrição Clínica",
    text: "Maycon é excelente! Consegui mudar meus hábitos alimentares e perdi 8kg em 3 meses.",
    rating: 5,
  },
  {
    id: "test-3",
    patientName: "Sandra Ribeiro",
    service: "Pilates Clínico",
    text: "Pilates na MOOVE mudou minha vida! Sinto-me muito mais forte e com melhor postura.",
    rating: 5,
  },
];

export const mockUserProfile: UserProfile = {
  id: "user-1",
  name: "João Silva",
  email: "joao@example.com",
  phone: "(32) 99999-9999",
  birthDate: "1990-05-15",
  address: "Rua das Flores, 123 - Tocantins, MG",
};

export const clinicInfo = {
  name: "MOOVE Clínica",
  address: "Rua Maestro Antônio Bernardino, 73 – Bela Vista, Tocantins – MG",
  phone: "(32) 99988-5842",
  website: "https://www.mooveclinica.com.br",
  whatsapp: "https://api.whatsapp.com/send?phone=5532999885842",
  instagram: "https://www.instagram.com/moove_clinica/",
  instagramHandle: "@moove_clinica",
  hours: {
    weekday: "08:00 - 18:00",
    saturday: "09:00 - 13:00",
    sunday: "Fechado",
  },
};
