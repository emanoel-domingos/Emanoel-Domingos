// Domain Types for MOOVE Clínica App

export type Specialty = 
  | "Reabilitação"
  | "Movimento"
  | "Beleza & Saúde"
  | "Nutrição"
  | "Nutrição Esportiva"
  | "Nefrologia Renal"
  | "Saúde Mental"
  | "Procedimentos";

export type Service = 
  | "Fisioterapia Especializada"
  | "Pilates Clínico"
  | "Estética Avançada"
  | "Nutrição Clínica"
  | "Nutrição Esportiva"
  | "Nefrologia Renal"
  | "Psicologia"
  | "Biomedicina Estética";

export type AppointmentStatus = "confirmado" | "pendente" | "cancelado" | "concluído";

export interface Professional {
  id: string;
  name: string;
  specialty: Specialty;
  specialties: Specialty[];
  bio?: string;
  rating: number;
  reviews: number;
  image?: string;
  availableHours: string[];
  certifications?: string[]; // Certificações e especializações
}

export interface ServiceItem {
  id: string;
  name: Service;
  specialty: Specialty;
  description: string;
  price: number;
  image?: string;
  professionals: string[]; // IDs
  relatedServices?: string[]; // IDs de serviços relacionados
}

export interface Plan {
  id: string;
  name: string;
  frequency: string;
  sessionsPerMonth: number;
  price: number;
  highlighted?: boolean;
  description?: string;
}

export interface Appointment {
  id: string;
  serviceId: string;
  professionalId: string;
  date: string; // ISO date
  time: string; // HH:mm
  status: AppointmentStatus;
  notes?: string;
  createdAt: string;
}

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  phone: string;
  birthDate?: string;
  address?: string;
  profileImage?: string;
}

export interface Testimonial {
  id: string;
  patientName: string;
  service: Service;
  text: string;
  rating: number;
  image?: string;
}

export interface SpecialtyInfo {
  id: string;
  name: Specialty;
  description: string;
  professionals: string[]; // IDs
}
