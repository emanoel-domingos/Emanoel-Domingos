import { Pressable, View, type PressableProps } from "react-native";
import { Animated, Easing } from "react-native";
import { useRef, useEffect } from "react";
import * as Haptics from "expo-haptics";
import { cn } from "@/lib/utils";

interface PressableFeedbackProps extends PressableProps {
  className?: string;
  children: React.ReactNode;
  enableHaptics?: boolean;
  scale?: number;
  opacity?: number;
}

/**
 * Pressable com feedback visual melhorado
 * Inclui animação de escala, opacidade e haptic feedback
 */
export function PressableFeedback({
  className,
  children,
  enableHaptics = true,
  scale = 0.97,
  opacity = 0.85,
  onPress,
  ...props
}: PressableFeedbackProps) {
  const scaleAnim = useRef(new Animated.Value(1)).current;
  const opacityAnim = useRef(new Animated.Value(1)).current;

  const handlePressIn = () => {
    if (enableHaptics) {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }

    Animated.parallel([
      Animated.timing(scaleAnim, {
        toValue: scale,
        duration: 100,
        easing: Easing.out(Easing.cubic),
        useNativeDriver: true,
      }),
      Animated.timing(opacityAnim, {
        toValue: opacity,
        duration: 100,
        useNativeDriver: true,
      }),
    ]).start();
  };

  const handlePressOut = () => {
    Animated.parallel([
      Animated.timing(scaleAnim, {
        toValue: 1,
        duration: 150,
        easing: Easing.out(Easing.cubic),
        useNativeDriver: true,
      }),
      Animated.timing(opacityAnim, {
        toValue: 1,
        duration: 150,
        useNativeDriver: true,
      }),
    ]).start();
  };

  return (
    <Pressable
      onPress={onPress}
      onPressIn={handlePressIn}
      onPressOut={handlePressOut}
      {...props}
    >
      {({ pressed }) => (
        <Animated.View
          style={[
            {
              transform: [{ scale: scaleAnim }],
              opacity: opacityAnim,
            },
          ]}
        >
          <View className={className}>{children}</View>
        </Animated.View>
      )}
    </Pressable>
  );
}
