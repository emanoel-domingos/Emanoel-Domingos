import { View, TouchableOpacity, Text, StyleSheet } from "react-native";
import { BottomTabBarProps } from "@react-navigation/bottom-tabs";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useColors } from "@/hooks/use-colors";
import { Ionicons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";

const ICON_MAP: Record<string, { active: string; inactive: string }> = {
  index: { active: "home", inactive: "home-outline" },
  appointments: { active: "calendar", inactive: "calendar-outline" },
  services: { active: "heart", inactive: "heart-outline" },
  professionals: { active: "people", inactive: "people-outline" },
  reviews: { active: "star", inactive: "star-outline" },
  profile: { active: "person", inactive: "person-outline" },
};

const LABEL_MAP: Record<string, string> = {
  index: "Home",
  appointments: "Agenda",
  services: "Serviços",
  professionals: "Equipe",
  reviews: "Avaliações",
  profile: "Perfil",
};

export function CustomTabBar({ state, descriptors, navigation }: BottomTabBarProps) {
  const colors = useColors();
  const insets = useSafeAreaInsets();

  return (
    <View
      style={[
        styles.container,
        {
          backgroundColor: colors.background,
          borderTopColor: colors.border,
          paddingBottom: insets.bottom,
        },
      ]}
    >
      <View style={styles.tabsWrapper}>
        {state.routes.map((route, index) => {
          const isFocused = state.index === index;
          const icons = ICON_MAP[route.name] || { active: "help", inactive: "help-outline" };
          const label = LABEL_MAP[route.name] || route.name;

          const onPress = () => {
            Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
            const event = navigation.emit({
              type: "tabPress",
              target: route.key,
              canPreventDefault: true,
            });

            if (!isFocused && !event.defaultPrevented) {
              navigation.navigate(route.name, route.params);
            }
          };

          return (
            <TouchableOpacity
              key={route.key}
              onPress={onPress}
              activeOpacity={0.7}
              style={styles.tab}
            >
              <View
                style={[
                  styles.tabContent,
                  isFocused && {
                    backgroundColor: colors.primary + "15",
                    borderRadius: 12,
                  },
                ]}
              >
                <Ionicons
                  name={(isFocused ? icons.active : icons.inactive) as any}
                  size={24}
                  color={isFocused ? colors.primary : colors.muted}
                  style={styles.icon}
                />
                <Text
                  style={[
                    styles.label,
                    {
                      color: isFocused ? colors.primary : colors.muted,
                      fontWeight: isFocused ? "600" : "400",
                      fontSize: isFocused ? 11 : 10,
                    },
                  ]}
                  numberOfLines={1}
                >
                  {label}
                </Text>
              </View>
            </TouchableOpacity>
          );
        })}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    borderTopWidth: 1,
    paddingTop: 8,
    paddingHorizontal: 4,
  },
  tabsWrapper: {
    flexDirection: "row",
    justifyContent: "space-around",
    alignItems: "center",
    height: 56,
  },
  tab: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: 8,
  },
  tabContent: {
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: 6,
    paddingHorizontal: 8,
    gap: 4,
  },
  icon: {
    marginBottom: 2,
  },
  label: {
    textAlign: "center",
  },
});
