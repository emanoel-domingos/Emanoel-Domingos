import { View, Text } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { useColors } from "@/hooks/use-colors";
import type { Testimonial } from "@/lib/types";

interface TestimonialCardProps {
  testimonial: Testimonial;
}

/**
 * Card de depoimento/avaliação de paciente
 */
export function TestimonialCard({ testimonial }: TestimonialCardProps) {
  const colors = useColors();

  return (
    <View className="bg-surface rounded-xl p-4 border border-border mb-3">
      {/* Header com nome e rating */}
      <View className="flex-row items-start justify-between mb-3">
        <View className="flex-1">
          <Text className="text-sm font-semibold text-foreground">
            {testimonial.patientName}
          </Text>
          <Text className="text-xs text-muted">
            {testimonial.service}
          </Text>
        </View>
        <View className="flex-row items-center gap-1 bg-primary/10 px-2 py-1 rounded-full">
          <Ionicons name="star" size={12} color="#FFB800" />
          <Text className="text-xs font-semibold text-foreground">
            {testimonial.rating.toFixed(1)}
          </Text>
        </View>
      </View>

      {/* Texto do depoimento */}
      <Text className="text-sm text-foreground leading-relaxed mb-3">
        "{testimonial.text}"
      </Text>

      {/* Estrelas de rating */}
      <View className="flex-row gap-1">
        {Array.from({ length: 5 }).map((_, i) => (
          <Ionicons
            key={i}
            name={i < testimonial.rating ? "star" : "star-outline"}
            size={14}
            color="#FFB800"
          />
        ))}
      </View>
    </View>
  );
}
