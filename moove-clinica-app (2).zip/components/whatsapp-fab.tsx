import { TouchableOpacity, Linking } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { useColors } from "@/hooks/use-colors";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useClinicData } from "@/hooks/use-clinic-data";

/**
 * Floating Action Button (FAB) para WhatsApp
 * Aparece em todas as telas para facilitar contato rápido
 */
export function WhatsAppFAB() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { clinicInfo } = useClinicData();

  const handleWhatsAppPress = () => {
    Linking.openURL(clinicInfo.whatsapp);
  };

  return (
    <TouchableOpacity
      onPress={handleWhatsAppPress}
      style={{
        position: "absolute",
        bottom: Math.max(insets.bottom + 20, 80),
        right: 20,
        width: 60,
        height: 60,
        borderRadius: 30,
        backgroundColor: "#25D366",
        justifyContent: "center",
        alignItems: "center",
        shadowColor: "#000",
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.25,
        shadowRadius: 3.84,
        elevation: 5,
      }}
      activeOpacity={0.8}
    >
      <Ionicons name="logo-whatsapp" size={28} color="#fff" />
    </TouchableOpacity>
  );
}
