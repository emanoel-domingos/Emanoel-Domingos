import { View, TextInput, Pressable } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { useColors } from "@/hooks/use-colors";
import { cn } from "@/lib/utils";

interface SearchBarProps {
  placeholder?: string;
  value: string;
  onChangeText: (text: string) => void;
  onClear?: () => void;
  className?: string;
}

/**
 * Barra de pesquisa reutilizável com ícone de busca e limpeza
 */
export function SearchBar({
  placeholder = "Pesquisar...",
  value,
  onChangeText,
  onClear,
  className,
}: SearchBarProps) {
  const colors = useColors();

  return (
    <View className={cn("flex-row items-center gap-2 px-4 py-3 bg-surface rounded-xl border border-border", className)}>
      <Ionicons name="search" size={18} color={colors.muted} />
      <TextInput
        placeholder={placeholder}
        placeholderTextColor={colors.muted}
        value={value}
        onChangeText={onChangeText}
        className="flex-1 text-foreground text-base"
        style={{ color: colors.foreground }}
      />
      {value.length > 0 && (
        <Pressable
          onPress={() => {
            onChangeText("");
            onClear?.();
          }}
          hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
        >
          <Ionicons name="close-circle" size={18} color={colors.muted} />
        </Pressable>
      )}
    </View>
  );
}
