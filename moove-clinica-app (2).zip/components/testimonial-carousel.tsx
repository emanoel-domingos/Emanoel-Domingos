import { View, Text, ScrollView, TouchableOpacity, Dimensions } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { useColors } from "@/hooks/use-colors";
import { useRef, useState } from "react";
import type { Testimonial } from "@/lib/types";
import * as Haptics from "expo-haptics";

interface TestimonialCarouselProps {
  testimonials: Testimonial[];
  title?: string;
  onCategoryChange?: (category: string | null) => void;
}

const { width } = Dimensions.get("window");
const CARD_WIDTH = width - 48; // 24px padding on each side

/**
 * Carrossel de depoimentos com filtro por categoria
 */
export function TestimonialCarousel({
  testimonials,
  title = "Depoimentos em Destaque",
  onCategoryChange,
}: TestimonialCarouselProps) {
  const colors = useColors();
  const scrollViewRef = useRef<ScrollView>(null);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [currentIndex, setCurrentIndex] = useState(0);

  // Extrair categorias únicas
  const categories = Array.from(new Set(testimonials.map((t) => t.service)));

  // Filtrar depoimentos por categoria
  const filteredTestimonials = selectedCategory
    ? testimonials.filter((t) => t.service === selectedCategory)
    : testimonials;

  // Ordenar por rating (melhores primeiro)
  const sortedTestimonials = [...filteredTestimonials].sort(
    (a, b) => b.rating - a.rating
  );

  const handleCategoryPress = (category: string | null) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    setSelectedCategory(category);
    setCurrentIndex(0);
    onCategoryChange?.(category);
  };

  const handleScroll = (event: any) => {
    const contentOffsetX = event.nativeEvent.contentOffset.x;
    const index = Math.round(contentOffsetX / CARD_WIDTH);
    setCurrentIndex(index);
  };

  if (sortedTestimonials.length === 0) {
    return null;
  }

  return (
    <View className="gap-4">
      {/* Header */}
      <View className="px-6 gap-2">
        <Text className="text-lg font-bold text-foreground">{title}</Text>
        {selectedCategory && (
          <Text className="text-sm text-muted">{selectedCategory}</Text>
        )}
      </View>

      {/* Category Filter */}
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={{ paddingHorizontal: 24, gap: 8 }}
      >
        <TouchableOpacity
          onPress={() => handleCategoryPress(null)}
          className={`px-4 py-2 rounded-full ${
            selectedCategory === null
              ? "bg-primary"
              : "bg-surface border border-border"
          }`}
        >
          <Text
            className={`font-medium text-sm ${
              selectedCategory === null ? "text-white" : "text-foreground"
            }`}
          >
            Todos
          </Text>
        </TouchableOpacity>

        {categories.map((category) => (
          <TouchableOpacity
            key={category}
            onPress={() => handleCategoryPress(category)}
            className={`px-4 py-2 rounded-full ${
              selectedCategory === category
                ? "bg-primary"
                : "bg-surface border border-border"
            }`}
          >
            <Text
              className={`font-medium text-sm ${
                selectedCategory === category
                  ? "text-white"
                  : "text-foreground"
              }`}
            >
              {category}
            </Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      {/* Carousel */}
      <ScrollView
        ref={scrollViewRef}
        horizontal
        pagingEnabled
        showsHorizontalScrollIndicator={false}
        scrollEventThrottle={16}
        onScroll={handleScroll}
        contentContainerStyle={{ paddingHorizontal: 24 }}
      >
        {sortedTestimonials.map((testimonial, index) => (
          <View
            key={testimonial.id}
            style={{ width: CARD_WIDTH }}
            className="pr-4"
          >
            <View className="bg-surface rounded-xl p-5 border border-border h-full">
              {/* Header */}
              <View className="flex-row items-start justify-between mb-3">
                <View className="flex-1">
                  <Text className="text-sm font-semibold text-foreground">
                    {testimonial.patientName}
                  </Text>
                  <Text className="text-xs text-muted mt-1">
                    {testimonial.service}
                  </Text>
                </View>
                <View className="bg-primary/10 px-2 py-1 rounded-full">
                  <View className="flex-row items-center gap-1">
                    <Ionicons name="star" size={12} color="#FFB800" />
                    <Text className="text-xs font-bold text-primary">
                      {testimonial.rating.toFixed(1)}
                    </Text>
                  </View>
                </View>
              </View>

              {/* Text */}
              <Text
                className="text-sm text-foreground leading-relaxed flex-1 mb-4"
                numberOfLines={4}
              >
                "{testimonial.text}"
              </Text>

              {/* Stars */}
              <View className="flex-row gap-1">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Ionicons
                    key={i}
                    name={i < testimonial.rating ? "star" : "star-outline"}
                    size={12}
                    color="#FFB800"
                  />
                ))}
              </View>
            </View>
          </View>
        ))}
      </ScrollView>

      {/* Pagination Dots */}
      <View className="flex-row items-center justify-center gap-2 pb-2">
        {sortedTestimonials.map((_, index) => (
          <TouchableOpacity
            key={index}
            onPress={() => {
              Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
              scrollViewRef.current?.scrollTo({
                x: CARD_WIDTH * index,
                animated: true,
              });
            }}
            className={`rounded-full ${
              index === currentIndex
                ? "bg-primary w-2 h-2"
                : "bg-border w-1.5 h-1.5"
            }`}
          />
        ))}
      </View>

      {/* Counter */}
      <View className="px-6 items-center">
        <Text className="text-xs text-muted">
          {currentIndex + 1} de {sortedTestimonials.length}
        </Text>
      </View>
    </View>
  );
}
